#4 june 2026
- create new version code, arduino IDE based in new_version. all program unused removed.
- currently, base program using new_version/base/base.ino but attachment still using MSD/1011-main/attachment/sagadelabo/msd-controller-esp-now-experiment-sub-board-firmware
