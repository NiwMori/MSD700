#include "msd.hpp"

// ######### parameters #########
float g_input_propo_joy_leftY;
float g_input_propo_joy_leftX;
float g_input_propo_joy_rightY;
float g_input_propo_joy_rightX;
// control command data
double g_linear_x = 0;
double g_angular_z = 0;
float g_cylinder_1;
float g_cylinder_2;
float g_cylinder_3;
int g_power_relay = 0;  // propo switch A : 0:on 1:off
// calculate variable for encoder
int g_left_rpm = 0;
int g_right_rpm = 0;
// propo switch variable
int g_select_controler = 0;  // propo switch C : 0:propo 1:jetson
bool g_motor_brake = true;   // false:Neutral true:Brake On

float g_battery_level;

void CanInitialize() {
  twai_general_config_t g_config = TWAI_GENERAL_CONFIG_DEFAULT(kCanTx, kCanRx, TWAI_MODE_NORMAL);
  twai_timing_config_t t_config = TWAI_TIMING_CONFIG_250KBITS();  // CAN Rate Setting: SCiBのレートに設定
  twai_filter_config_t f_config = TWAI_FILTER_CONFIG_ACCEPT_ALL();
  esp_err_t twai_returns;

  twai_returns = twai_driver_install(&g_config, &t_config, &f_config);
  while (twai_returns == ESP_ERR_INVALID_ARG | twai_returns == ESP_ERR_NO_MEM) {
    switch (twai_returns) {
      case ESP_ERR_INVALID_ARG:
        printf("twai_driver_install: ESP_ERR_INVALID_ARG\n");
        break;
      case ESP_ERR_NO_MEM:
        printf("twai_driver_install: ESP_ERR_NO_MEM\n");
        break;
      case ESP_ERR_INVALID_STATE:
        printf("twai_driver_install: ESP_ERR_INVALID_STATE\n");
        break;
      default:
        printf("twai_driver_install: ESP_OK\n");
        break;
    }
    twai_returns = twai_driver_install(&g_config, &t_config, &f_config);
  }
}

void CanTerminate() {
  twai_stop();
  twai_driver_uninstall();
}

void IoExpanderInitialize() {
  mcp.begin_I2C(kMCP_Address);
  mcp.pinMode(kIoExpanderFowardLeft, OUTPUT);
  mcp.pinMode(kIoExpanderRverseLeft, OUTPUT);
  mcp.pinMode(kIoExpanderStopModeLeft, OUTPUT);
  mcp.pinMode(kIoExpanderM0Left, OUTPUT);
  mcp.pinMode(kIoExpanderAlarmResetLeft, OUTPUT);
  mcp.pinMode(kIoExpanderMbFreeLeft, OUTPUT);
  mcp.pinMode(kIoExpanderEmergencyStopSwitch1, OUTPUT);

  mcp.pinMode(kIoExpanderFowardRight, OUTPUT);
  mcp.pinMode(kIoExpanderRverseRight, OUTPUT);
  mcp.pinMode(kIoExpanderStopModeRight, OUTPUT);
  mcp.pinMode(kIoExpanderM0Right, OUTPUT);
  mcp.pinMode(kIoExpanderAlarmResetRight, OUTPUT);
  mcp.pinMode(kIoExpanderMbFreeRight, OUTPUT);
  mcp.pinMode(kIoExpanderEmergencyStopSwitch2, OUTPUT);

  mcp.pinMode(kIoExpanderSpeedOutLeft, INPUT);
  mcp.pinMode(kIoExpanderSpeedOutRight, INPUT);

  mcp.digitalWrite(kIoExpanderStopModeRight, LOW);
  mcp.digitalWrite(kIoExpanderStopModeLeft, LOW);
  mcp.digitalWrite(kIoExpanderMbFreeRight, HIGH);
  mcp.digitalWrite(kIoExpanderMbFreeLeft, HIGH);
  mcp.digitalWrite(kIoExpanderM0Right, HIGH);
  mcp.digitalWrite(kIoExpanderM0Left, HIGH);
}

void GpioModeSet() {
  gpio_set_direction(kRcTransmitterCh1, GPIO_MODE_INPUT);
  gpio_set_direction(kRcTransmitterCh3, GPIO_MODE_INPUT);
  gpio_set_direction(kRcTransmitterCh2, GPIO_MODE_INPUT);
  gpio_set_direction(kRcTransmitterCh4, GPIO_MODE_INPUT);
  gpio_set_direction(kRcTransmitterCh5, GPIO_MODE_INPUT);
  gpio_set_direction(kRcTransmitterCh6, GPIO_MODE_INPUT);
  gpio_set_direction(kMoterPowerRelay, GPIO_MODE_OUTPUT);

  gpio_set_direction(kVMRight, GPIO_MODE_OUTPUT);
  gpio_set_direction(kVMLeft, GPIO_MODE_OUTPUT);
}

void setup() {
  Serial.begin(115200);  // For debug
  while (!Serial) {
    printf("---> Initialize Error: Serial\n");
    continue;
  }
  Serial1.begin(115200, SERIAL_8N1, kUart1Rx, kUart1Tx);  // For Jetson
  while (!Serial1) {
    printf("---> Initialize Error: Serial1\n");
    continue;
  }
  Serial1.setTimeout(100);
  GpioModeSet();

  while (gpio_pullup_en(kSDA) != ESP_OK) continue;
  while (gpio_pullup_en(kSCL) != ESP_OK) continue;
  Wire.setPins(kSDA, kSCL);
  Wire.begin();
  bno.begin();
  bno.setExtCrystalUse(true);

  IoExpanderInitialize();
  CanInitialize();
}

void loop() {
  feedback_data["battery_level"] = 0;
  feedback_data["fb_cylinder_1"] = 0.00;
  feedback_data["fb_cylinder_2"] = 0.00;
  feedback_data["imu_euler_x"] = 0.00;  // zがx
  feedback_data["imu_euler_y"] = 0.00;
  feedback_data["left_encoder"] = 0;
  feedback_data["right_encoder"] = 0;

  int msd_state;
  // # input control command
  receivePropoSwitch();

  // # move
  // ## motor drive
  switch (g_power_relay) {
    case 0:
      digitalWrite(kMoterPowerRelay, LOW);
      stopMotor(g_motor_brake);
      msd_state = 2;
      break;
    case 1:
      digitalWrite(kMoterPowerRelay, HIGH);

      switch (g_select_controler) {
        case 0:
          receivePropoJoy(0.30);
          g_linear_x   = g_input_propo_joy_leftY * LINEAR_SPEED_MAX;
          g_angular_z  = g_input_propo_joy_leftX * ANGULAR_SPEED_MAX;
          g_cylinder_1 = g_input_propo_joy_rightY;
          g_cylinder_2 = g_input_propo_joy_rightX;
          pixels.setPixelColor(0, pixels.Color(BRIGHTNESS, 0, BRIGHTNESS));
          pixels.show();
          msd_state = 1;
          break;
        case 1:
          receivePropoJoy(0.30);
          g_angular_z  = - g_input_propo_joy_leftY * 0.5;
          g_cylinder_1 = g_input_propo_joy_leftX;
          g_cylinder_2 = g_input_propo_joy_rightY;
          g_cylinder_3 = - g_input_propo_joy_rightX;
          Serial.println(g_cylinder_1);
          Serial.println(g_cylinder_2);
          Serial.println(g_cylinder_3);
          pixels.setPixelColor(0, pixels.Color(0, BRIGHTNESS, 0));
          pixels.show();
          msd_state = 0;
          break;
      break;  
      }
      ik(g_linear_x, g_angular_z);
      writeMotorPwm(g_left_rpm, g_right_rpm);
  }

  feedback_data["power_relay"] = g_power_relay;
  readImu(0);

  // ## can send
  CanInitialize();
  twai_start();

  uint8_t power_relay_can[sizeof(float)];
  memcpy(power_relay_can, &g_power_relay, sizeof(int));
  CanTransmitter(kPowerReleyCanId, 0, power_relay_can);

  uint8_t msd_state_can[sizeof(int)];
  memcpy(msd_state_can, &msd_state, sizeof(int));
  Serial.print(msd_state_can[0]);
  CanTransmitter(kMsdStateCanId, 0, msd_state_can);

  uint8_t cylinder_1_can[sizeof(float)];
  memcpy(cylinder_1_can, &g_cylinder_1, sizeof(float));
  CanTransmitter(kCylinder1CanId, 0, cylinder_1_can);

  uint8_t cylinder_2_can[sizeof(float)];
  memcpy(cylinder_2_can, &g_cylinder_2, sizeof(float));
  CanTransmitter(kCylinder2CanId, 0, cylinder_2_can);

  uint8_t cylinder_3_can[sizeof(float)];
  memcpy(cylinder_3_can, &g_cylinder_3, sizeof(float));
  CanTransmitter(kCylinder3CanId, 0, cylinder_3_can);

  // ## can receive
  Serial.println("+++++++++++++++ CAN RX +++++++++++++++");
  twai_message_t cylinder_feedback1_can;
  if (twai_receive(&cylinder_feedback1_can, kCanTimeOut) == ESP_OK && cylinder_feedback1_can.identifier == kCylinder1FeedbackCanId) {
    int cylinder_feedback1;
    memcpy(&cylinder_feedback1, cylinder_feedback1_can.data, sizeof(int));
    Serial.print("Cylinder FB1: ");
    Serial.println(cylinder_feedback1);
    cylinder_feedback1 = map(cylinder_feedback1, 0, 4095, 0, 100);
    feedback_data["fb_cylinder_1"] = cylinder_feedback1;
  }
  twai_message_t cylinder_feedback2_can;
  if (twai_receive(&cylinder_feedback2_can, kCanTimeOut) == ESP_OK && cylinder_feedback2_can.identifier == kCylinder2FeedbackCanId) {
    int cylinder_feedback2;
    memcpy(&cylinder_feedback2, cylinder_feedback2_can.data, sizeof(int));
    Serial.print("Cylinder FB2: ");
    Serial.println(cylinder_feedback2);
    cylinder_feedback2 = map(cylinder_feedback2, 0, 4095, 0, 100);
    feedback_data["fb_cylinder_2"] = cylinder_feedback2;
  }

  // battery level
  // int battery_level_056 = ReadBatteryLevel(0x056);
  // int battery_level_076 = ReadBatteryLevel(0x076);
  // feedback_data["battery_level"] = (battery_level_056 < battery_level_076) ? battery_level_056 : battery_level_076;
  // g_battery_level = feedback_data["battery_level"];
  twai_stop();

  // # send to jetson
  // serializeJson(feedback_data, Serial1);
  // Serial1.println();
  serializeJson(feedback_data, Serial);
  Serial.println();
}

void receivePropoSwitch() {
  int togle_A = pulseIn(kRcTransmitterCh5, HIGH);  // down x2056/2057 (1510.5) up 963/x964
  int togle_B = pulseIn(kRcTransmitterCh6, HIGH);  // down x2056/2057 (1510) up 963/x964

  if (togle_A < 1510) {  // up
    g_power_relay = 0;
  } else if (togle_A > 1510) {  // down
    g_power_relay = 1;
  }

  if (togle_B < 1510) {  // up
    g_select_controler = 1;
  } else if (togle_B > 1510) {  // down
    g_select_controler = 0;
  }
}

void receivePropoJoy(float deadzone) {  // input proportional controler joysticks
  int PROPO_JOY_MAX = 1930;
  int PROPO_JOY_MIN = 1109;
  float input_propo_joy_leftY = map(pulseIn(kRcTransmitterCh2, HIGH), PROPO_JOY_MAX, PROPO_JOY_MIN, -100, 100) / 100.0;  // left joy Y
  float input_propo_joy_leftX = map(pulseIn(kRcTransmitterCh4, HIGH), PROPO_JOY_MAX, PROPO_JOY_MIN, -100, 100) / 100.0;  // left joy X
  float input_propo_joy_rightY = map(pulseIn(kRcTransmitterCh3, HIGH), PROPO_JOY_MAX, PROPO_JOY_MIN, -100, 100) / -100.0;
  float input_propo_joy_rightX = map(pulseIn(kRcTransmitterCh1, HIGH), PROPO_JOY_MAX, PROPO_JOY_MIN, -100, 100) / 100.0;

  // dead zone
  if (-deadzone <= input_propo_joy_leftX && input_propo_joy_leftX <= deadzone) {
    input_propo_joy_leftX = 0.00;
  }
  if (-deadzone <= input_propo_joy_leftY && input_propo_joy_leftY <= deadzone) {
    input_propo_joy_leftY = 0.00;
  }

  if (-deadzone <= input_propo_joy_rightY && input_propo_joy_rightY <= deadzone) {
    input_propo_joy_rightY = 0.00;
  }
  if (-deadzone <= input_propo_joy_rightX && input_propo_joy_rightX <= deadzone) {
    input_propo_joy_rightX = 0.00;
  }
  g_input_propo_joy_leftY = input_propo_joy_leftY;
  g_input_propo_joy_leftX = input_propo_joy_leftX;
  g_input_propo_joy_rightY = input_propo_joy_rightY;
  g_input_propo_joy_rightX = input_propo_joy_rightX;
}

void receiveSerialFromJetson() {
  JsonDocument doc;
  if (Serial1.available() > 0) {
    DeserializationError err1;
    while (!(err1.code() == DeserializationError::Ok)) {
      String recived_serial_data = Serial1.readStringUntil('\n');
      err1 = deserializeJson(doc, recived_serial_data);
    }
    g_linear_x = doc["linear_x"];
    g_angular_z = doc["angular_z"];
    g_cylinder_1 = doc["cylinder_1"];
    g_cylinder_2 = doc["cylinder_2"];
    g_power_relay = doc["power_relay"];
    printf("x:%lf\n");
    printf("z:%lf\n");
    printf("1:%f\n");
    printf("2:%f\n");
    printf("relay:%d\n");
  }
}

float velToRpm(float v) {
  // convert velocity to rpm
  const float REDUCTION_RATIO = 100.0;  // 減速比 reduction ratio
  const float WHEEL_RADIUS = 0.1105;    // 車輪半径 radius of gyration [m]
  float n = 30 / M_PI * REDUCTION_RATIO / WHEEL_RADIUS * v;

  return n;
}

void ik(float v, float w) {
  // calculate linear velocity and angur velocity to left and right velocity
  float WHEEL_DISTANCE = 0.600;  // 車輪間距離 distance between the wheels [m]
  float v_l = v - WHEEL_DISTANCE * w;
  float v_r = v + WHEEL_DISTANCE * w;

  float left_rpm = velToRpm(v_l);
  float right_rpm = velToRpm(v_r);

  // direction of motor
  if (left_rpm > 0) {
    mcp.digitalWrite(kIoExpanderFowardLeft, HIGH);
    mcp.digitalWrite(kIoExpanderRverseLeft, LOW);
    // Serial.print("Left dir:FWD, ");
  } else if (left_rpm < 0) {
    mcp.digitalWrite(kIoExpanderFowardLeft, LOW);
    mcp.digitalWrite(kIoExpanderRverseLeft, HIGH);
    // Serial.print("Left dir:REV, ");
  } else {
    mcp.digitalWrite(kIoExpanderFowardLeft, LOW);
    mcp.digitalWrite(kIoExpanderRverseLeft, LOW);
    // Serial.print("Left dir:stop, ");
  }

  if (right_rpm > 0) {
    mcp.digitalWrite(kIoExpanderFowardRight, LOW);
    mcp.digitalWrite(kIoExpanderRverseRight, HIGH);
    // Serial.print("Right dir:FWD, ");
  } else if (right_rpm < 0) {
    mcp.digitalWrite(kIoExpanderFowardRight, HIGH);
    mcp.digitalWrite(kIoExpanderRverseRight, LOW);
    // Serial.print("Right dir:REV, ");
  } else {
    mcp.digitalWrite(kIoExpanderFowardRight, LOW);
    mcp.digitalWrite(kIoExpanderRverseRight, LOW);
    // Serial.print("Right dir:stop, ");
  }
  // formar 1:backet, 2:brade

  if (left_rpm < 0 || right_rpm < 0) {
    g_left_rpm = right_rpm;
    g_right_rpm = left_rpm;
  } else {
    g_left_rpm = left_rpm;
    g_right_rpm = right_rpm;
  }
}

void stopMotor(bool motor_brake_state) {
  // HIGH:ブレーキ解放 LOW:ブレーキ保持
  if (motor_brake_state == 0) {
    mcp.digitalWrite(kIoExpanderMbFreeLeft, HIGH);
    mcp.digitalWrite(kIoExpanderMbFreeRight, HIGH);
  } else if (motor_brake_state == 1) {
    mcp.digitalWrite(kIoExpanderMbFreeLeft, LOW);
    mcp.digitalWrite(kIoExpanderMbFreeRight, LOW);
  }
  analogWrite(kVMLeft, 0);
  analogWrite(kVMRight, 0);
  //=== STOP表示 ===
  // Serial.print("Motor stop, ");
}

void writeMotorPwm(int left_rpm, int right_rpm) {
  int left_pwm;
  int right_pwm;

  left_rpm = abs(left_rpm);
  right_rpm = abs(right_rpm);

  left_rpm = min(left_rpm, 4000);
  left_rpm = max(left_rpm, 0);

  right_rpm = min(right_rpm, 4000);
  right_rpm = max(right_rpm, 0);

  left_pwm = map(left_rpm, 0, 4000, 0, 255);
  right_pwm = map(right_rpm, 0, 4000, 0, 255);

  if (left_pwm && right_pwm == 0) {
    stopMotor(g_motor_brake);
  } else {
    analogWrite(kVMLeft, left_pwm);
    analogWrite(kVMRight, right_pwm);
  }
  // motor encoder
  feedback_data["left_rpm"] = left_rpm;
  feedback_data["right_rpm"] = right_rpm;
  // Serial.print("left_pwm");
  // Serial.print(left_pwm);
  // Serial.print("right_pwm");
  // Serial.println(right_pwm);
}

void readImu(int kBNO055_SAMPLERATE_DELAY_MS) {
  imu::Vector<3> euler = bno.getVector(Adafruit_BNO055::VECTOR_EULER);
  // imu::Quaternion quat = bno.getQuat();

  feedback_data["imu_euler_x"] = euler.z();  // zがx
  feedback_data["imu_euler_y"] = euler.y();

  // feedback_data["imu_euler"].to<JsonObject>()["euler_x"] = euler.x();
  // feedback_data["imu_euler"].to<JsonObject>()["euler_y"] = euler.y();
  // feedback_data["imu_euler"].to<JsonObject>()["euler_z"] = euler.z();

  // feedback_data["imu_quat"].to<JsonObject>()["quat_w"] = quat.w();
  // feedback_data["imu_quat"].to<JsonObject>()["quat_x"] = quat.x();
  // feedback_data["imu_quat"].to<JsonObject>()["quat_y"] = quat.y();
  // feedback_data["imu_quat"].to<JsonObject>()["quat_z"] = quat.z();

  delay(kBNO055_SAMPLERATE_DELAY_MS);
}

void CanTransmitter(uint32_t identifier, uint32_t extd, uint8_t send_data[]) {
  twai_message_t message_transmit;
  message_transmit.identifier = identifier;
  message_transmit.extd = extd;
  message_transmit.data_length_code = sizeof(&send_data) / sizeof(uint8_t);
  message_transmit.flags = TWAI_MSG_FLAG_NONE;

  for (size_t i = 0; i < message_transmit.data_length_code; i++) {
    message_transmit.data[i] = send_data[i];
  }

  twai_transmit(&message_transmit, kCanTimeOut);

  vTaskDelay(30);

  // Serial.printf("\n++++++++++ CAN CONTENTS ++++++++++\n");

  // Serial.printf("identifier: %x\n", message_transmit.identifier);
  // Serial.printf("extd: %u\n", message_transmit.extd);
  // Serial.printf("data_length_code: %u\n", message_transmit.data_length_code);
  // for (size_t i = 0; i < message_transmit.data_length_code; i++) {
  //   Serial.printf("data%d: %u\n", i, message_transmit.data[i]);
  // }

  // Serial.printf("\n++++++++++++++++++++++++++++++++\n");
}

twai_message_t CanReceiver(uint32_t identifier) {
  twai_message_t message_receive;

  while (1) {
    esp_err_t result = twai_receive(&message_receive, kCanTimeOut);
    // Serial.printf("Waiting ID: %x ---->", identifier);
    if (result == ESP_OK) {
      // printf("Message received\n");
      if (message_receive.identifier == identifier) break;
    } else if (result == ESP_ERR_TIMEOUT) {
      printf("ESP_ERR_TIMEOUT: twai_receive()\n");
    } else if (result == ESP_ERR_INVALID_ARG) {
      printf("ESP_ERR_INVALID_ARG: twai_receive()\n");
    } else if (result == ESP_ERR_INVALID_STATE) {
      printf("ESP_ERR_INVALID_STATE: twai_receive()\n");
    } else {
      printf("ESP_ERR: twai_receive()\n");
    }
  }

  Serial.printf("==================== Message received====================\n");
  if (message_receive.extd) {
    Serial.printf("Format:Extended\n");
    // printf("Data length is %d\n", message_receive.data_length_code);
  } else {
    Serial.printf("Format: Standard\n");
    // printf("Data length is %d\n", message_receive.data_length_code);
  }
  Serial.printf("ID: %x\n", message_receive.identifier);
  if (!(message_receive.rtr)) {
    for (int i = 0; i < message_receive.data_length_code; i++) {
      Serial.printf("Data byte %d => HEX: 0x%x, BIN: 0b%s\n", i, message_receive.data[i], ConvertFromHex2Bin(message_receive.data[i]));
    }
    Serial.printf("==========================================================\n");
  }

  return message_receive;
}

void CanReceiver4Debug() {
  twai_message_t message_receive;

  // Wait for message to be received
  if (twai_receive(&message_receive, kCanTimeOut) == ESP_OK) {
    Serial.printf("----->\n");
  } else if (twai_receive(&message_receive, kCanTimeOut) ==
             ESP_ERR_TIMEOUT) {
    Serial.printf("ESP_ERR_TIMEOUT: twai_receive()\n");
  } else if (twai_receive(&message_receive, kCanTimeOut) ==
             ESP_ERR_INVALID_ARG) {
    Serial.printf("ESP_ERR_INVALID_ARG: twai_receive()\n");
  } else if (twai_receive(&message_receive, kCanTimeOut) ==
             ESP_ERR_INVALID_STATE) {
    Serial.printf("ESP_ERR_INVALID_STATE: twai_receive()\n");
  } else {
    return;
  }

  // Process received message
  Serial.printf("==================== Message received　====================\n");
  if (message_receive.extd) {
    Serial.printf("Format: Extended\n");
    printf("Data length is %d\n", message_receive.data_length_code);
  } else {
    Serial.printf("Format: Standard\n");
    printf("Data length is %d\n", message_receive.data_length_code);
  }
  Serial.printf("ID: %x\n", message_receive.identifier);
  if (!(message_receive.rtr)) {
    for (int i = 0; i < message_receive.data_length_code; i++) {
      Serial.printf("Data byte %d => HEX: 0x%x, BIN: 0b%s\n", i,
                    message_receive.data[i],
                    ConvertFromHex2Bin(message_receive.data[i]));
    }
    Serial.printf("==========================================================\n");
  }
}

void ReadBattery(uint32_t can_identifier) {
  twai_message_t can_data;
  can_data = CanReceiver(can_identifier);

  float can_data_array[sizeof(twai_message_t)];
  std::memcpy(can_data_array, &can_data, sizeof(twai_message_t));
}

int ReadBatteryLevel(uint32_t can_identifier) {
  twai_message_t can_data = CanReceiver(can_identifier);

  const float kBatteryMaxVolt = 28600;  // Unit: mV
  const float kBatteryMinVolt = 20000;  // Unit: mV

  uint8_t can_data_byte_3 = can_data.data[3];
  uint8_t can_data_byte_4 = can_data.data[4];

  uint16_t hex = ConvertFromTwoBytes2DoubleByte(can_data_byte_3, can_data_byte_4);

  float battery_level_millivolt = hex * 4.8832;
  float battery_level_percent = {(battery_level_millivolt - kBatteryMinVolt) / (kBatteryMaxVolt - kBatteryMinVolt) * 100};
  return battery_level_percent;
}

String ConvertFromHex2Bin(uint8_t hex_num) {
  using namespace std;

  stringstream ss;
  string s;
  String str;

  ss << std::bitset<sizeof(uint8_t) * CHAR_BIT>(hex_num);
  s = ss.str();
  str = s.c_str();

  return str;
}

uint16_t ConvertFromTwoBytes2DoubleByte(uint8_t byte_1, uint8_t byte_2) {
  uint8_t two_bytes[2] = {byte_1, byte_2};  // 1byteが２つ
  uint16_t double_byte = (two_bytes[0] << 8) | two_bytes[1];

  return double_byte;
}

bool EmergencySwitchState() {
  bool emergency_stop_switch_state;
  if (mcp.digitalRead(kIoExpanderEmergencyStopSwitch1) == LOW) {
    emergency_stop_switch_state = true;
  } else {
    emergency_stop_switch_state = false;
  }
  float state[] = {false};
  state[0] = emergency_stop_switch_state;
  return emergency_stop_switch_state;
}