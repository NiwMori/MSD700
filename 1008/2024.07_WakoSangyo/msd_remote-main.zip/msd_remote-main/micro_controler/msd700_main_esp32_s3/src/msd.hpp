#ifndef MSD_HPP
#define MSD_HPP

#include <Adafruit_BNO055.h>
#include <Adafruit_MCP23X17.h>
#include <Adafruit_Sensor.h>
#include <Arduino.h>
#include <ArduinoJson.h>
#include <SPIFFS.h>
#include <Wire.h>
#include <utility/imumaths.h>

#include <bitset>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <sstream>

#include "Adafruit_NeoPixel.h"
#include "driver/gpio.h"
#include "driver/twai.h"


const gpio_num_t kNeoPixel = GPIO_NUM_48;          // NeoPixel　の出力ピン = 番号;
const gpio_num_t kMoterPowerRelay = GPIO_NUM_17;   // pin No.5 relay swit = ch;
const gpio_num_t kRcTransmitterCh1 = GPIO_NUM_40;  // 8 right horizontal = X
const gpio_num_t kRcTransmitterCh2 = GPIO_NUM_39;  // 3 left vertical = Y
const gpio_num_t kRcTransmitterCh3 = GPIO_NUM_38;  // 46 right vertical = Y
const gpio_num_t kRcTransmitterCh4 = GPIO_NUM_37;  // 9 left horizontal = X
const gpio_num_t kRcTransmitterCh5 = GPIO_NUM_36;  // 10 A
const gpio_num_t kRcTransmitterCh6 = GPIO_NUM_35;  // 11 B
const gpio_num_t kSDA = GPIO_NUM_18;
const gpio_num_t kSCL = GPIO_NUM_8;
const gpio_num_t kCanTx = GPIO_NUM_6;
const gpio_num_t kCanRx = GPIO_NUM_7;
const gpio_num_t kUart1Tx = GPIO_NUM_4;
const gpio_num_t kUart1Rx = GPIO_NUM_5;
const gpio_num_t kUart2Tx = GPIO_NUM_15;
const gpio_num_t kUart2Rx = GPIO_NUM_16;
const gpio_num_t kVMLeft = GPIO_NUM_42;
const gpio_num_t kVMRight = GPIO_NUM_41;

// IO expander pin assign
const uint8_t kIoExpanderFowardLeft = 0;      // FWD_L
const uint8_t kIoExpanderRverseLeft = 1;      // REV_L
const uint8_t kIoExpanderStopModeLeft = 2;    // STOP_MODE_L
const uint8_t kIoExpanderM0Left = 3;          // M0_L
const uint8_t kIoExpanderAlarmResetLeft = 4;  // ALARM_RESET_L
const uint8_t kIoExpanderMbFreeLeft = 5;      // MB_FREE_L
const uint8_t kIoExpanderSpeedOutLeft = 6;    // SPEED_OUT_L
const uint8_t kIoExpanderEmergencyStopSwitch1 = 7;
const uint8_t kIoExpanderFowardRight = 8;       // FWD_R
const uint8_t kIoExpanderRverseRight = 9;       // REV_R
const uint8_t kIoExpanderStopModeRight = 10;    // STOP_MODE_R
const uint8_t kIoExpanderM0Right = 11;          // M0_R
const uint8_t kIoExpanderAlarmResetRight = 12;  // ALARM_RESET_R
const uint8_t kIoExpanderMbFreeRight = 13;      // MB_FREE_R
const uint8_t kIoExpanderSpeedOutRight = 14;    // SPEED_OUT_R
const uint8_t kIoExpanderEmergencyStopSwitch2 = 15;

const int LED_COUNT = 1;   // LEDの連 = 結数;
const int BRIGHTNESS = 1;  //  = 輝度;
Adafruit_NeoPixel pixels(LED_COUNT, kNeoPixel, NEO_GRB + NEO_KHZ800);

Adafruit_BNO055 bno = Adafruit_BNO055(-1, 0x28, &Wire);

Adafruit_MCP23X17 mcp;
const int kMCP_Address = 0x20;

const TickType_t kCanTimeOut = pdMS_TO_TICKS(500);  // Unit: milliseconds
const uint32_t kCylinder1CanId = 0x200;
const uint32_t kCylinder2CanId = 0x201;
const uint32_t kCylinder3CanId = 0x206;
const uint32_t kPowerReleyCanId = 0x202;
const uint32_t kMsdStateCanId = 0x203;
const uint32_t kCylinder1FeedbackCanId = 0x204;
const uint32_t kCylinder2FeedbackCanId = 0x205;

JsonDocument feedback_data;
JsonDocument command_data;

// ######### parameters #########
// calculation velocity to rpm
#define M_PI 3.14159265358979323846
double LINEAR_SPEED_MAX = 0.462861317;
double ANGULAR_SPEED_MAX = 0.764398163;

void CanInitialize();
void CanTerminate();
void IoExpanderInitialize();
void GpioModeSet();
void receivePropoSwitch();
void receivePropoJoy(float deadzone);
void receiveSerialFromJetson();
void ik(float v, float w);
void stopMotor(bool motor_brake_state);
void writeMotorPwm(int left_rpm, int right_rpm);
void readImu(int kBNO055_SAMPLERATE_DELAY_MS);
void CanTransmitter(uint32_t identifier, uint32_t extd, uint8_t uart_data[]);
void CanReceiver4Debug();
void ReadBattery(uint32_t can_identifier);
int ReadBatteryLevel(uint32_t can_identifier);

uint16_t ConvertFromTwoBytes2DoubleByte(uint8_t byte_1, uint8_t byte_2);
float velToRpm(float v);
String ConvertFromHex2Bin(uint8_t hex_num);
twai_message_t CanReceiver(uint32_t identifier);
bool EmergencySwitchState();


#endif