#include <Adafruit_BNO055.h>
#include <Adafruit_MCP23X17.h>
#include <Adafruit_Sensor.h>
#include <Arduino.h>
#include <ArduinoJson.h>
#include <SPIFFS.h>
#include <Wire.h>
#include <utility/imumaths.h>

#include <bitset>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <sstream>

#include "Adafruit_NeoPixel.h"
#include "driver/gpio.h"
#include "driver/twai.h"
#include "esp_task_wdt.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

// extern HardwareSerial Serial1;
// extern HardwareSerial Serial2;

const gpio_num_t kNeoPixel = GPIO_NUM_48;          // NeoPixel　の出力ピン = 番号;
const gpio_num_t kMoterPowerRelay = GPIO_NUM_17;   // pin No.5 relay swit = ch;
const gpio_num_t kRcTransmitterCh1 = GPIO_NUM_40;  // 8 right horizontal = X
const gpio_num_t kRcTransmitterCh2 = GPIO_NUM_39;  // 3 left vertical = Y
const gpio_num_t kRcTransmitterCh3 = GPIO_NUM_38;  // 46 right vertical = Y
const gpio_num_t kRcTransmitterCh4 = GPIO_NUM_37;  // 9 left horizontal = X
const gpio_num_t kRcTransmitterCh5 = GPIO_NUM_36;  // 10 A
const gpio_num_t kRcTransmitterCh6 = GPIO_NUM_35;  // 11 B
const gpio_num_t kSDA = GPIO_NUM_18;
const gpio_num_t kSCL = GPIO_NUM_8;
const gpio_num_t kCanTx = GPIO_NUM_6;
const gpio_num_t kCanRx = GPIO_NUM_7;
const gpio_num_t kUart1Tx = GPIO_NUM_4;
const gpio_num_t kUart1Rx = GPIO_NUM_5;
const gpio_num_t kUart2Tx = GPIO_NUM_15;
const gpio_num_t kUart2Rx = GPIO_NUM_16;
const gpio_num_t kVMLeft = GPIO_NUM_42;
const gpio_num_t kVMRight = GPIO_NUM_41;

// IO expander pin assign
const uint8_t kIoExpanderFowardLeft = 0;      // FWD_L
const uint8_t kIoExpanderRverseLeft = 1;      // REV_L
const uint8_t kIoExpanderStopModeLeft = 2;    // STOP_MODE_L
const uint8_t kIoExpanderM0Left = 3;          // M0_L
const uint8_t kIoExpanderAlarmResetLeft = 4;  // ALARM_RESET_L
const uint8_t kIoExpanderMbFreeLeft = 5;      // MB_FREE_L
const uint8_t kIoExpanderSpeedOutLeft = 6;    // SPEED_OUT_L
const uint8_t kIoExpanderEmergencyStopSwitch1 = 7;
const uint8_t kIoExpanderFowardRight = 8;       // FWD_R
const uint8_t kIoExpanderRverseRight = 9;       // REV_R
const uint8_t kIoExpanderStopModeRight = 10;    // STOP_MODE_R
const uint8_t kIoExpanderM0Right = 11;          // M0_R
const uint8_t kIoExpanderAlarmResetRight = 12;  // ALARM_RESET_R
const uint8_t kIoExpanderMbFreeRight = 13;      // MB_FREE_R
const uint8_t kIoExpanderSpeedOutRight = 14;    // SPEED_OUT_R
const uint8_t kIoExpanderEmergencyStopSwitch2 = 15;

// calculation velocity to rpm
#define M_PI 3.14159265358979323846
float LINEAR_SPEED_MAX = 0.462861317;
float ANGULAR_SPEED_MAX = 0.785398163;

const int LED_COUNT = 1;   // LEDの連 = 結数;
const int BRIGHTNESS = 1;  //  = 輝度;
Adafruit_NeoPixel pixels(LED_COUNT, kNeoPixel, NEO_GRB + NEO_KHZ800);

const TickType_t kCanTimeOut = pdMS_TO_TICKS(500);  // Unit: milliseconds
const int kBaudRateUsbSerial = 115200;              // for debug
const int kBaudRateUart1 = 115200;                    // for jetson
const int kBaudRateUart2 = 115200;                    // for main micro computer

Adafruit_BNO055 bno = Adafruit_BNO055(-1, 0x28, &Wire);

Adafruit_MCP23X17 mcp;
const int kMCP_Address = 0x20;

const float kBatteryMaxVolt = 28600;  // Unit: mV
const float kBatteryMinVolt = 20000;  // Unit: mV

const auto kRcTransmitterDeadZone = 0.30;

const TickType_t kRtosQueueTimeOut = 10 / portTICK_PERIOD_MS;  // 10ms

// APP CPU
const UBaseType_t kRcTransmitterPriority = 2;
const UBaseType_t kI2cPriority = 1;
// PRO CPU TASK
const UBaseType_t kCanTxPriority = 2;
const UBaseType_t kCanRxPriority = 2;
const UBaseType_t kUartTxPriority = 1;
const UBaseType_t kUartRxPriority = 1;

const int kBNO055_SAMPLERATE_DELAY_MS = 10;

const uint32_t kCylinder1CanId = 0x200;
const uint32_t kCylinder2CanId = 0x201;
const uint32_t kPowerReleyCanId = 0x202;
const uint32_t kMsdStateCanId = 0x203;
const uint32_t kCylinder1FeedbackCanId = 0x204;
const uint32_t kCylinder2FeedbackCanId = 0x205;

const TickType_t xLoopDelay = pdMS_TO_TICKS(1);                      // 1Tick
const TickType_t xCanRxTaskDelay = 50 / portTICK_PERIOD_MS;          // 50ms
const TickType_t xCanTxTaskDelay = 50 / portTICK_PERIOD_MS;          // 50ms
const TickType_t xUartTxTaskDelay = 50 / portTICK_PERIOD_MS;         // 50ms
const TickType_t xUartRxTaskDelay = 50 / portTICK_PERIOD_MS;         // 50ms
const TickType_t xI2cTaskDelay = 50 / portTICK_PERIOD_MS;            // 50ms
const TickType_t xRcTransmitterTaskDelay = 50 / portTICK_PERIOD_MS;  // 50ms

JsonDocument doc_4_debug;
JsonDocument doc_4_sub;
JsonDocument doc_4_jetson;

JsonDocument jdoc_receive_serial_data_1;
JsonDocument jdoc_receive_serial_data_2;
JsonDocument jdoc_receive_serial_data_3;

JsonDocument feedback_data;

QueueHandle_t queue_rc_transmitter_switch;
QueueHandle_t queue_rc_transmitter_joy;
QueueHandle_t queue_linear_x;
QueueHandle_t queue_angular_z;
QueueHandle_t queue_cylinder_1;
QueueHandle_t queue_cylinder_2;
QueueHandle_t queue_left_rpm;
QueueHandle_t queue_right_rpm;
QueueHandle_t queue_mode_switch;       // none : 0:bucket mode 1:others mode
QueueHandle_t queue_select_controler;  // B : 1:propo 0:jetson
QueueHandle_t queue_motor_brake;       // none : 0:neutral 1:brake
QueueHandle_t queue_left_encoder;
QueueHandle_t queue_right_encoder;
QueueHandle_t queue_power_relay;  // A : 0:on 1:off
QueueHandle_t queue_emergency_switch_state;
QueueHandle_t queue_msd_state;
QueueHandle_t queue_can_tx;

void CanTxTask(void *pvParameters);
void CanRxTask(void *pvParameters);
void UartTxTask(void *pvParameters);
void UartRxTask(void *pvParameters);
void I2cTask(void *pvParameters);
void RcTransmitterTask(void *pvParameters);

void receiveSerialFromJetson();
void ik(float v, float w);
void stopMotor();
void writeMotorPwm(int left_rpm, int right_rpm);
void JsonGenerator(JsonDocument &doc, int data_count, String key, float data[]);
void SendJson(JsonDocument &doc, int serial_port_num);
void readImu();
void CanTransmitter(uint32_t identifier, uint32_t extd, uint8_t uart_data[]);
void CanReceiver4Debug();
void ReadBattery(uint32_t can_identifier);
void ReadBatteryLevel(uint32_t can_identifier);

uint16_t ConvertFromTwoBytes2DoubleByte(uint8_t byte_1, uint8_t byte_2);
float velToRpm(float v);
String ConvertFromHex2Bin(uint8_t hex_num);
twai_message_t CanReceiver(uint32_t identifier);
bool EmergencySwitchState();
void speedOut();

void SerialInitialize() {
  Serial1.begin(kBaudRateUart1, SERIAL_8N1, kUart1Rx, kUart1Tx);  // For Jetson
  while (!Serial1) {
    printf("---> Initialize Error: Serial1\n");
    continue;
  }
  Serial2.begin(kBaudRateUart2, SERIAL_8N1, kUart2Tx, kUart2Rx);
  while (!Serial2) {
    printf("---> Initialize Error: Serial2\n");
    continue;
  }
}

void CanInitialize() {
  twai_general_config_t g_config = TWAI_GENERAL_CONFIG_DEFAULT(kCanTx, kCanRx, TWAI_MODE_NORMAL);
  twai_timing_config_t t_config = TWAI_TIMING_CONFIG_250KBITS();  // CAN Rate Setting: SCiBのレートに設定
  twai_filter_config_t f_config = TWAI_FILTER_CONFIG_ACCEPT_ALL();
  esp_err_t twai_returns;

  twai_returns = twai_driver_install(&g_config, &t_config, &f_config);
  while (twai_returns == ESP_ERR_INVALID_ARG | twai_returns == ESP_ERR_NO_MEM) {
    switch (twai_returns) {
      case ESP_ERR_INVALID_ARG:
        printf("twai_driver_install: ESP_ERR_INVALID_ARG\n");
        break;
      case ESP_ERR_NO_MEM:
        printf("twai_driver_install: ESP_ERR_NO_MEM\n");
        break;
      case ESP_ERR_INVALID_STATE:
        printf("twai_driver_install: ESP_ERR_INVALID_STATE\n");
        break;
      default:
        printf("twai_driver_install: ESP_OK\n");
        break;
    }
    twai_returns = twai_driver_install(&g_config, &t_config, &f_config);
  }
}

void CanTerminate() {
  twai_stop();
  twai_driver_uninstall();
}

void I2cInitialize() {
  while (gpio_pullup_en(kSDA) != ESP_OK) continue;
  while (gpio_pullup_en(kSCL) != ESP_OK) continue;
  Wire.setPins(kSDA, kSCL);
  Wire.begin();
}

void IoExpanderInitialize() {
  mcp.begin_I2C(kMCP_Address);
  mcp.pinMode(kIoExpanderFowardLeft, OUTPUT);
  mcp.pinMode(kIoExpanderRverseLeft, OUTPUT);
  mcp.pinMode(kIoExpanderStopModeLeft, OUTPUT);
  mcp.pinMode(kIoExpanderM0Left, OUTPUT);
  mcp.pinMode(kIoExpanderAlarmResetLeft, OUTPUT);
  mcp.pinMode(kIoExpanderMbFreeLeft, OUTPUT);
  mcp.pinMode(kIoExpanderEmergencyStopSwitch1, OUTPUT);

  mcp.pinMode(kIoExpanderFowardRight, OUTPUT);
  mcp.pinMode(kIoExpanderRverseRight, OUTPUT);
  mcp.pinMode(kIoExpanderStopModeRight, OUTPUT);
  mcp.pinMode(kIoExpanderM0Right, OUTPUT);
  mcp.pinMode(kIoExpanderAlarmResetRight, OUTPUT);
  mcp.pinMode(kIoExpanderMbFreeRight, OUTPUT);
  mcp.pinMode(kIoExpanderEmergencyStopSwitch2, OUTPUT);

  mcp.pinMode(kIoExpanderSpeedOutLeft, INPUT);
  mcp.pinMode(kIoExpanderSpeedOutRight, INPUT);

  mcp.digitalWrite(kIoExpanderStopModeRight, LOW);
  mcp.digitalWrite(kIoExpanderStopModeLeft, LOW);
  mcp.digitalWrite(kIoExpanderMbFreeRight, HIGH);
  mcp.digitalWrite(kIoExpanderMbFreeLeft, HIGH);
  mcp.digitalWrite(kIoExpanderM0Right, HIGH);
  mcp.digitalWrite(kIoExpanderM0Left, HIGH);
}

void ImuInitialize() {
  while (!bno.begin()) continue;
  bno.setExtCrystalUse(true);
}

void QueueCreate() {
  queue_rc_transmitter_switch  = xQueueCreate(2, sizeof(int));  // Queue size: 1, Item size: 7 float elements
  queue_rc_transmitter_joy     = xQueueCreate(4, sizeof(float));   // Queue size: 1, Item size: 7 float elements
  queue_linear_x               = xQueueCreate(1, sizeof(float));
  queue_angular_z              = xQueueCreate(1, sizeof(float));
  queue_cylinder_1             = xQueueCreate(1, sizeof(float));
  queue_cylinder_2             = xQueueCreate(1, sizeof(float));
  queue_left_rpm               = xQueueCreate(1, sizeof(float));
  queue_right_rpm              = xQueueCreate(1, sizeof(float));
  queue_mode_switch            = xQueueCreate(1, sizeof(int));
  queue_select_controler       = xQueueCreate(1, sizeof(int));
  queue_motor_brake            = xQueueCreate(1, sizeof(int));
  queue_left_encoder           = xQueueCreate(1, sizeof(float));
  queue_right_encoder          = xQueueCreate(1, sizeof(float));
  queue_power_relay            = xQueueCreate(1, sizeof(int));
  queue_emergency_switch_state = xQueueCreate(1, sizeof(bool));
  queue_msd_state              = xQueueCreate(1, sizeof(int));
  queue_can_tx                 = xQueueCreate(1, sizeof(twai_message_t));
}

void TaskCreate() {
  TaskHandle_t can_tx_task_handle;
  TaskHandle_t can_rx_task_handle;
  TaskHandle_t uart_tx_task_handle;
  TaskHandle_t uart_rx_task_handle;
  TaskHandle_t i2c_task_handle;
  TaskHandle_t rc_transmitter_task_handle;

  xTaskCreatePinnedToCore(CanTxTask, "CAN TX Task", 65536, NULL, kCanTxPriority, &can_tx_task_handle, PRO_CPU_NUM);
  xTaskCreatePinnedToCore(CanRxTask, "CAN RX Task", 65536, NULL, kCanRxPriority, &can_rx_task_handle, PRO_CPU_NUM);
  xTaskCreatePinnedToCore(UartTxTask, "UART Tx Task", 8192, NULL, kUartTxPriority, &uart_tx_task_handle, PRO_CPU_NUM);
  xTaskCreatePinnedToCore(UartRxTask, "UART Rx Task", 8192, NULL, kUartRxPriority, &uart_rx_task_handle, PRO_CPU_NUM);
  xTaskCreatePinnedToCore(I2cTask, "I2C Task", 8192, NULL, kI2cPriority, &i2c_task_handle, APP_CPU_NUM);
  xTaskCreatePinnedToCore(RcTransmitterTask, "RC Transmitter Task", 8192, NULL, kRcTransmitterPriority, &rc_transmitter_task_handle, APP_CPU_NUM);
}

void GpioModeSet() {
  gpio_set_direction(kRcTransmitterCh1, GPIO_MODE_INPUT);
  gpio_set_direction(kRcTransmitterCh3, GPIO_MODE_INPUT);
  gpio_set_direction(kRcTransmitterCh2, GPIO_MODE_INPUT);
  gpio_set_direction(kRcTransmitterCh4, GPIO_MODE_INPUT);
  gpio_set_direction(kRcTransmitterCh5, GPIO_MODE_INPUT);
  gpio_set_direction(kRcTransmitterCh6, GPIO_MODE_INPUT);
  gpio_set_direction(kMoterPowerRelay, GPIO_MODE_OUTPUT);

  gpio_set_direction(kVMRight, GPIO_MODE_OUTPUT);
  gpio_set_direction(kVMLeft, GPIO_MODE_OUTPUT);
}

void setup() {
  Serial.begin(kBaudRateUsbSerial);  // For debug
  while (!Serial) {
    printf("---> Initialize Error: Serial\n");
    continue;
  }

  Serial1.setRxBufferSize(1024);
  Serial2.setRxBufferSize(1024);

  Serial1.setTimeout(100);
  Serial2.setTimeout(100);

  GpioModeSet();
  QueueCreate();
  TaskCreate();

  Serial.println("========== Start Program ==========");
}

void loop() { vTaskDelay(xLoopDelay); }

void CanTxTask(void *pcParameters) {
  CanInitialize();
  while (1) {
    // CanInitialize();
    // Serial.println("=== can tx task ===");

    // while (twai_start() != ESP_OK) continue;

    twai_start();

    uint8_t cylinder_1_can[sizeof(float)];
    float cylinder_1_queue;
    xQueueReceive(queue_cylinder_1, &cylinder_1_queue, kRtosQueueTimeOut);
    memcpy(cylinder_1_can, &cylinder_1_queue, sizeof(float));
    CanTransmitter(kCylinder1CanId, 0, cylinder_1_can);

    uint8_t cylinder_2_can[sizeof(float)];
    float cylinder_2_queue;
    xQueueReceive(queue_cylinder_2, &cylinder_2_queue, kRtosQueueTimeOut);
    memcpy(cylinder_2_can, &cylinder_2_queue, sizeof(float));
    CanTransmitter(kCylinder2CanId, 0, cylinder_2_can);

    uint8_t power_relay_can[sizeof(int)];
    int power_relay_queue;
    xQueueReceive(queue_power_relay, &power_relay_queue, kRtosQueueTimeOut);
    memcpy(power_relay_can, &power_relay_queue, sizeof(int));
    CanTransmitter(kPowerReleyCanId, 0, power_relay_can);

    uint8_t msd_state_can[sizeof(int)];
    int msd_state_queue;
    xQueueReceive(queue_msd_state, &msd_state_queue, kRtosQueueTimeOut);
    memcpy(msd_state_can, &msd_state_queue, sizeof(int));
    CanTransmitter(kMsdStateCanId, 0, msd_state_can);

    // CanTerminate();
    // twai_stop();

    vTaskDelay(xCanTxTaskDelay);
  }
}

void CanRxTask(void *pvParameters) {
  CanInitialize();
  while (1) {
    twai_start();
    // CanInitialize();
    printf("+++++++++++++++ CAN RX +++++++++++++++\n");
    twai_message_t cylinder_feedback1_can;

    if (twai_receive(&cylinder_feedback1_can, kCanTimeOut) == ESP_OK && cylinder_feedback1_can.identifier == kCylinder1FeedbackCanId) {
      int cylinder_feedback1;
      memcpy(&cylinder_feedback1, cylinder_feedback1_can.data, sizeof(int));
      // printf("\nCylinder FB1: %d\n", cylinder_feedback1);
      cylinder_feedback1 = map(cylinder_feedback1, 0, 4095, 0, 100);
      feedback_data["fb_cylinder_1"] = cylinder_feedback1;
    }

    twai_message_t cylinder_feedback2_can;
    if (twai_receive(&cylinder_feedback2_can, kCanTimeOut) == ESP_OK && cylinder_feedback2_can.identifier == kCylinder2FeedbackCanId) {
      int cylinder_feedback2;
      memcpy(&cylinder_feedback2, cylinder_feedback2_can.data, sizeof(int));
      // printf("\nCylinder FB2: %d\n", cylinder_feedback2);
      cylinder_feedback2 = map(cylinder_feedback2, 0, 4095, 0, 100);
      feedback_data["fb_cylinder_2"] = cylinder_feedback2;
    }

    // CanTerminate();

    // twai_stop();

    vTaskDelay(xCanRxTaskDelay);
  }
}

void UartTxTask(void *pvParameters) {
  // SerialInitialize();
  while (1) {
    Serial.println("=== uart tx task ===");
    Serial.print("feedback_data:");
    serializeJson(feedback_data, Serial);
    Serial.println();
    serializeJson(feedback_data, Serial1);
    Serial1.println();
    serializeJson(feedback_data, Serial2);
    Serial2.println();

    vTaskDelay(xUartTxTaskDelay);
  }
}

void UartRxTask(void *pvParameters) {
  SerialInitialize();
  while (1) {
    // Serial.println("=== uart rx task ===");
    int select_controler;
    xQueueReceive(queue_select_controler, &select_controler, kRtosQueueTimeOut);

    switch (select_controler) {
      case 0:
        Serial.println("-----> Jetson");
        receiveSerialFromJetson();
        break;
      case 1:
        Serial.println("-----> Propo");
        break;
      default:
        Serial.println("---> STOP --->");
        break;
    }

    vTaskDelay(xUartRxTaskDelay);
  }
}

void I2cTask(void *pvParameters) {
  I2cInitialize();
  IoExpanderInitialize();
  ImuInitialize();

  float left_rpm;
  float right_rpm;
  float linear_x;
  float angular_z;
  int power_relay_state;
  int mode_switch_state_lamp;

  while (1) {
    // Serial.println("=== i2c task ===");

    xQueueReceive(queue_power_relay, &power_relay_state, kRtosQueueTimeOut);
    xQueueReceive(queue_mode_switch, &mode_switch_state_lamp, kRtosQueueTimeOut);

    if (power_relay_state == false) {
      // digitalWrite(kMoterPowerRelay, LOW);
      stopMotor();
    } else if (power_relay_state == true) {
      // digitalWrite(kMoterPowerRelay, HIGH);
      if (mode_switch_state_lamp == 0) {
        xQueueReceive(queue_linear_x, &linear_x, kRtosQueueTimeOut);
        xQueueReceive(queue_angular_z, &angular_z, kRtosQueueTimeOut);
      } else if (mode_switch_state_lamp == 1) {
        xQueueReceive(queue_linear_x, &linear_x, kRtosQueueTimeOut);
        xQueueReceive(queue_angular_z, &angular_z, kRtosQueueTimeOut);
      }

      ik(linear_x, angular_z);

      xQueueReceive(queue_left_rpm, &left_rpm, kRtosQueueTimeOut);
      xQueueReceive(queue_right_rpm, &right_rpm, kRtosQueueTimeOut);

      writeMotorPwm(left_rpm, right_rpm);

      feedback_data["left_rpm"] = left_rpm;
      feedback_data["right_rpm"] = right_rpm;
    }
    readImu();
    feedback_data["power_relay_state"] = static_cast<int>(EmergencySwitchState());

    vTaskDelay(xI2cTaskDelay);
  }
}

void RcTransmitterTask(void *pvParameters) {
  while (1) {
    // Serial.println("=== propo task ===");

    int togle_A = pulseIn(kRcTransmitterCh5, HIGH);
    int togle_B = pulseIn(kRcTransmitterCh6, HIGH);

    int data[2] = {togle_A, togle_B};
    xQueueSend(queue_rc_transmitter_switch, &data, kRtosQueueTimeOut);

    int power_relay;
    int select_controler;

    if (togle_A < 1510) {
      // up
      power_relay = 0;
      select_controler = 2;
      // Serial.println("-----> Power OFF");

      digitalWrite(kMoterPowerRelay, LOW);

      xQueueSend(queue_power_relay, &power_relay, kRtosQueueTimeOut);

    } else if (togle_A > 1510) {
      // down
      power_relay = 1;
      // Serial.println("-----> Power ON");
      digitalWrite(kMoterPowerRelay, HIGH);

      if (togle_B < 1510) {
        // up
        select_controler = 0;

        // Serial.println("-----> Controled by Jetson");
      } else if (togle_B > 1510) {
        // down
        select_controler = 1;

        // Serial.println("-----> Controled by RC Transmitter");
      }
    }

    xQueueSend(queue_msd_state, &select_controler, kRtosQueueTimeOut);
    xQueueSend(queue_select_controler, &select_controler, kRtosQueueTimeOut);

    float input_propo_joy_leftY = map(pulseIn(kRcTransmitterCh2, HIGH), 1109, 1929, 100, -100) / 100.0;  // left joy Y
    float input_propo_joy_leftX = map(pulseIn(kRcTransmitterCh4, HIGH), 1109, 1929, 100, -100) / 100.0;  // left joy X
    float input_propo_joy_rightY = map(pulseIn(kRcTransmitterCh3, HIGH), 1917, 1103, -100, 100) / -100.0;
    float input_propo_joy_rightX = map(pulseIn(kRcTransmitterCh1, HIGH), 1917, 1103, -100, 100) / 100.0;

    if (-kRcTransmitterDeadZone <= input_propo_joy_leftX && input_propo_joy_leftX <= kRcTransmitterDeadZone) input_propo_joy_leftX = 0.00;
    if (-kRcTransmitterDeadZone <= input_propo_joy_leftY && input_propo_joy_leftY <= kRcTransmitterDeadZone) input_propo_joy_leftY = 0.00;
    if (-kRcTransmitterDeadZone <= input_propo_joy_rightY && input_propo_joy_rightY <= kRcTransmitterDeadZone) input_propo_joy_rightY = 0.00;
    if (-kRcTransmitterDeadZone <= input_propo_joy_rightX && input_propo_joy_rightX <= kRcTransmitterDeadZone) input_propo_joy_rightX = 0.00;

    float data_to_send[4] = {input_propo_joy_rightX, input_propo_joy_leftY, input_propo_joy_rightY, input_propo_joy_leftX};
    xQueueSend(queue_rc_transmitter_joy, &data_to_send, kRtosQueueTimeOut);

    if (select_controler == 1) {
      float linear_x = input_propo_joy_leftY * LINEAR_SPEED_MAX;
      xQueueSend(queue_linear_x, &linear_x, kRtosQueueTimeOut);
      float angular_z = input_propo_joy_leftX * ANGULAR_SPEED_MAX;
      xQueueSend(queue_angular_z, &angular_z, kRtosQueueTimeOut);
      float cylinder_1 = input_propo_joy_rightY;
      xQueueSend(queue_cylinder_1, &cylinder_1, kRtosQueueTimeOut);
      float cylinder_2 = input_propo_joy_rightX;
      xQueueSend(queue_cylinder_2, &cylinder_2, kRtosQueueTimeOut);
      xQueueSend(queue_power_relay, &power_relay, kRtosQueueTimeOut);
    }

    vTaskDelay(xRcTransmitterTaskDelay);
  }
}



void receiveSerialFromJetson() {
  float linear_x = 0;
  float angular_z = 0;
  float cylinder_1 = 0;
  float cylinder_2 = 0;
  int power_relay = 0;

  String received_serial_data_1 = Serial1.readStringUntil('\n');
  // err1 = deserializeJson(jdoc_receive_serial_data_1, received_serial_data_1);
  Serial.print("received_serial_data_1:");
  Serial.println(received_serial_data_1);

  if (Serial1.available() > 0) {
    DeserializationError err1;
    while (!(err1.code() == DeserializationError::Ok)) {
      String received_serial_data_1 = Serial1.readStringUntil('\n');
      err1 = deserializeJson(jdoc_receive_serial_data_1, received_serial_data_1);
      Serial.print("json1:");
      Serial.println(received_serial_data_1);
    }

    String tmp_linear_x_str = jdoc_receive_serial_data_1["linear_x"];
    String tmp_angular_z_str = jdoc_receive_serial_data_1["angular_z"];
    String tmp_cylinder_1_str = jdoc_receive_serial_data_1["cylinder_1"];
    String tmp_cylinder_2_str = jdoc_receive_serial_data_1["cylinder_2"];
    String tmp_power_relay_str = jdoc_receive_serial_data_1["power_relay"];

    Serial.println("\n===== Json data for Jetson =====");
    Serial.printf("linear_x: %s\n", tmp_linear_x_str);
    Serial.printf("angular_z: %s\n", tmp_angular_z_str);
    Serial.printf("cylinder_1: %s\n", tmp_cylinder_1_str);
    Serial.printf("cylinder_2: %s\n", tmp_cylinder_2_str);
    Serial.printf("power_relay: %s\n", tmp_power_relay_str);
    Serial.println("\n================================");

    linear_x = tmp_linear_x_str.toFloat();
    angular_z = tmp_angular_z_str.toFloat();
    cylinder_1 = tmp_cylinder_1_str.toFloat();
    cylinder_2 = tmp_cylinder_2_str.toFloat();
    power_relay = tmp_power_relay_str.toInt();
  }

  xQueueSend(queue_linear_x, &linear_x, kRtosQueueTimeOut);
  xQueueSend(queue_angular_z, &angular_z, kRtosQueueTimeOut);
  xQueueSend(queue_cylinder_1, &cylinder_1, kRtosQueueTimeOut);
  xQueueSend(queue_cylinder_2, &cylinder_2, kRtosQueueTimeOut);
  xQueueSend(queue_power_relay, &power_relay, kRtosQueueTimeOut);
}

float velToRpm(float v) {
  // convert velocity to rpm
  const float REDUCTION_RATIO = 100.0;  // 減速比 reduction ratio
  const float WHEEL_RADIUS = 0.1105;    // 車輪半径 radius of gyration [m]
  float n = 30 / M_PI * REDUCTION_RATIO / WHEEL_RADIUS * v;

  return n;
}

void ik(float v, float w) {
  // calculate linear velocity and angur velocity to left and right velocity
  float WHEEL_DISTANCE = 0.600;  // 車輪間距離 distance between the wheels [m]
  float v_l = v - WHEEL_DISTANCE * w;
  float v_r = v + WHEEL_DISTANCE * w;

  float left_rpm = velToRpm(v_l);
  float right_rpm = velToRpm(v_r);

  xQueueSend(queue_left_rpm, &left_rpm, kRtosQueueTimeOut);
  xQueueSend(queue_right_rpm, &right_rpm, kRtosQueueTimeOut);

  // direction of motor
  if (left_rpm > 0) {
    mcp.digitalWrite(kIoExpanderFowardLeft, HIGH);
    mcp.digitalWrite(kIoExpanderRverseLeft, LOW);
    // Serial.print("Left dir:FWD, ");
  } else if (left_rpm < 0) {
    mcp.digitalWrite(kIoExpanderFowardLeft, LOW);
    mcp.digitalWrite(kIoExpanderRverseLeft, HIGH);
    // Serial.print("Left dir:REV, ");
  } else {
    mcp.digitalWrite(kIoExpanderFowardLeft, LOW);
    mcp.digitalWrite(kIoExpanderRverseLeft, LOW);
    // Serial.print("Left dir:stop, ");
  }

  if (right_rpm > 0) {
    mcp.digitalWrite(kIoExpanderFowardRight, LOW);
    mcp.digitalWrite(kIoExpanderRverseRight, HIGH);
    // Serial.print("Right dir:FWD, ");
  } else if (right_rpm < 0) {
    mcp.digitalWrite(kIoExpanderFowardRight, HIGH);
    mcp.digitalWrite(kIoExpanderRverseRight, LOW);
    // Serial.print("Right dir:REV, ");
  } else {
    mcp.digitalWrite(kIoExpanderFowardRight, LOW);
    mcp.digitalWrite(kIoExpanderRverseRight, LOW);
    // Serial.print("Right dir:stop, ");
  }

  int mode_switch_state_lamp;
  xQueueReceive(queue_mode_switch, &mode_switch_state_lamp, kRtosQueueTimeOut);
}

void stopMotor() {
  int motor_brake_state = 1;
  xQueueReceive(queue_motor_brake, &motor_brake_state, kRtosQueueTimeOut);

  if (motor_brake_state == 0) {
    // HIGH:ブレーキ解放 LOW:ブレーキ保持
    mcp.digitalWrite(kIoExpanderMbFreeLeft, HIGH);
    mcp.digitalWrite(kIoExpanderMbFreeRight, HIGH);
  } else if (motor_brake_state == 1) {
    // HIGH:ブレーキ解放 LOW:ブレーキ保持
    mcp.digitalWrite(kIoExpanderMbFreeLeft, LOW);
    mcp.digitalWrite(kIoExpanderMbFreeRight, LOW);
    // Serial.print("Brake, ");
  }
  analogWrite(kVMLeft, 0);
  analogWrite(kVMRight, 0);
  //=== STOP表示 ===
  // Serial.print("Motor stop, ");
}

void writeMotorPwm(int left_rpm, int right_rpm) {
  int left_pwm;
  int right_pwm;

  left_rpm = abs(left_rpm);
  right_rpm = abs(right_rpm);

  left_rpm = min(left_rpm, 4000);
  left_rpm = max(left_rpm, 0);

  right_rpm = min(right_rpm, 4000);
  right_rpm = max(right_rpm, 0);

  left_pwm = map(left_rpm, 0, 4000, 0, 255);
  right_pwm = map(right_rpm, 0, 4000, 0, 255);

  Serial.printf("left_pwm: %d, right_pwm: %d\n", left_pwm, right_pwm);

  if (left_pwm && right_pwm == 0) {
    stopMotor();
  } else {
    analogWrite(kVMLeft, left_pwm);
    analogWrite(kVMRight, right_pwm);
  }
}

void JsonGenerator(JsonDocument &doc, int data_count, String key, float data[]) {
  for (int i = 0; i < data_count; i++) {
    doc[key][i] = data[i];
  }
}

void SendJson(JsonDocument &doc, int serial_port_num) {
  switch (serial_port_num) {
    case 0:
      serializeJson(doc, Serial);  // debug
      break;
    case 1:
      serializeJson(doc, Serial1);  // jetson
      break;
    case 2:
      serializeJson(doc, Serial2);  // main
      break;
    default:
      break;
  }
}

void readImu() {
  imu::Vector<3> euler = bno.getVector(Adafruit_BNO055::VECTOR_EULER);
  // imu::Quaternion quat = bno.getQuat();

  feedback_data["imu_euler_x"] = euler.z(); // zがx
  feedback_data["imu_euler_y"] = euler.y();

  // feedback_data["imu_euler"].to<JsonObject>()["euler_x"] = euler.x();
  // feedback_data["imu_euler"].to<JsonObject>()["euler_y"] = euler.y();
  // feedback_data["imu_euler"].to<JsonObject>()["euler_z"] = euler.z();

  // feedback_data["imu_quat"].to<JsonObject>()["quat_w"] = quat.w();
  // feedback_data["imu_quat"].to<JsonObject>()["quat_x"] = quat.x();
  // feedback_data["imu_quat"].to<JsonObject>()["quat_y"] = quat.y();
  // feedback_data["imu_quat"].to<JsonObject>()["quat_z"] = quat.z();

  // delay(kBNO055_SAMPLERATE_DELAY_MS);
}

void CanTransmitter(uint32_t identifier, uint32_t extd, uint8_t send_data[]) {
  twai_message_t message_transmit;
  message_transmit.identifier = identifier;
  message_transmit.extd = extd;
  message_transmit.data_length_code = sizeof(&send_data) / sizeof(uint8_t);
  message_transmit.flags = TWAI_MSG_FLAG_NONE;

  for (size_t i = 0; i < message_transmit.data_length_code; i++) {
    message_transmit.data[i] = send_data[i];
  }

  twai_transmit(&message_transmit, kCanTimeOut);

  vTaskDelay(30);

  // Serial.printf("\n++++++++++ CAN CONTENTS ++++++++++\n");

  // Serial.printf("identifier: %x\n", message_transmit.identifier);
  // Serial.printf("extd: %u\n", message_transmit.extd);
  // Serial.printf("data_length_code: %u\n", message_transmit.data_length_code);
  // for (size_t i = 0; i < message_transmit.data_length_code; i++) {
  //   Serial.printf("data%d: %u\n", i, message_transmit.data[i]);
  // }

  // Serial.printf("\n++++++++++++++++++++++++++++++++\n");
}

twai_message_t CanReceiver(uint32_t identifier) {
  twai_message_t message_receive;

  while (1) {
    esp_err_t result = twai_receive(&message_receive, kCanTimeOut);
    Serial.printf("Waiting ID: %x ---->", identifier);
    if (result == ESP_OK) {
      printf("Message received\n");
      if (message_receive.identifier == identifier) break;
    } else if (result == ESP_ERR_TIMEOUT) {
      printf("ESP_ERR_TIMEOUT: twai_receive()\n");
    } else if (result == ESP_ERR_INVALID_ARG) {
      printf("ESP_ERR_INVALID_ARG: twai_receive()\n");
    } else if (result == ESP_ERR_INVALID_STATE) {
      printf("ESP_ERR_INVALID_STATE: twai_receive()\n");
    } else {
      printf("ESP_ERR: twai_receive()\n");
    }
  }
  /*
    Serial.printf("==================== Message received
    ====================\n"); if (message_receive.extd) { Serial.printf("Format:
    Extended\n");
      // printf("Data length is %d\n", message_receive.data_length_code);
    } else {
      Serial.printf("Format: Standard\n");
      // printf("Data length is %d\n", message_receive.data_length_code);
    }
    Serial.printf("ID: %x\n", message_receive.identifier);
    if (!(message_receive.rtr)) {
      for (int i = 0; i < message_receive.data_length_code; i++) {
        Serial.printf("Data byte %d => HEX: 0x%x, BIN: 0b%s\n", i,
                      message_receive.data[i],
                      ConvertFromHex2Bin(message_receive.data[i]));
      }
      Serial.printf(
          "==========================================================\n");
    }
  */
  return message_receive;
}

void CanReceiver4Debug() {
  twai_message_t message_receive;

  // Wait for message to be received
  if (twai_receive(&message_receive, kCanTimeOut) == ESP_OK) {
    Serial.printf("----->\n");
  } else if (twai_receive(&message_receive, kCanTimeOut) ==
             ESP_ERR_TIMEOUT) {
    Serial.printf("ESP_ERR_TIMEOUT: twai_receive()\n");
  } else if (twai_receive(&message_receive, kCanTimeOut) ==
             ESP_ERR_INVALID_ARG) {
    Serial.printf("ESP_ERR_INVALID_ARG: twai_receive()\n");
  } else if (twai_receive(&message_receive, kCanTimeOut) ==
             ESP_ERR_INVALID_STATE) {
    Serial.printf("ESP_ERR_INVALID_STATE: twai_receive()\n");
  } else {
    return;
  }

  // Process received message
  Serial.printf("==================== Message received　====================\n");
  if (message_receive.extd) {
    Serial.printf("Format: Extended\n");
    printf("Data length is %d\n", message_receive.data_length_code);
  } else {
    Serial.printf("Format: Standard\n");
    printf("Data length is %d\n", message_receive.data_length_code);
  }
  Serial.printf("ID: %x\n", message_receive.identifier);
  if (!(message_receive.rtr)) {
    for (int i = 0; i < message_receive.data_length_code; i++) {
      Serial.printf("Data byte %d => HEX: 0x%x, BIN: 0b%s\n", i,
                    message_receive.data[i],
                    ConvertFromHex2Bin(message_receive.data[i]));
    }
    Serial.printf("==========================================================\n");
  }
}

void ReadBattery(uint32_t can_identifier) {
  twai_message_t can_data;
  can_data = CanReceiver(can_identifier);

  float can_data_array[sizeof(twai_message_t)];
  std::memcpy(can_data_array, &can_data, sizeof(twai_message_t));

  JsonGenerator(doc_4_debug, sizeof(twai_message_t), "Battery", can_data_array);
  // SendJson(doc_4_debug, 0);
}

void ReadBatteryLevel(uint32_t can_identifier) {
  twai_message_t can_data = CanReceiver(can_identifier);

  uint8_t can_data_byte_3 = can_data.data[3];
  uint8_t can_data_byte_4 = can_data.data[4];

  uint16_t hex = ConvertFromTwoBytes2DoubleByte(can_data_byte_3, can_data_byte_4);

  float battery_level_millivolt = hex * 4.8832;
  float battery_level_percent[] = {(battery_level_millivolt - kBatteryMinVolt) / (kBatteryMaxVolt - kBatteryMinVolt) * 100};
  // Serial.printf("Battery Level => %f[mV]\n", battery_level_millivolt);
  // Serial.printf("Battery Level => %f[%]\n", battery_level_percent[0]);
  feedback_data["battery_level"] = battery_level_percent[0];

  String key;
  if (can_data.identifier == 0x056) key = "BatteryLevelModule1";
  if (can_data.identifier == 0x076) key = "BatteryLevelModule2";
  // JsonGenerator(doc_4_debug, 1, key, battery_level_percent);
  // SendJson(doc_4_debug, 0);
}

String ConvertFromHex2Bin(uint8_t hex_num) {
  using namespace std;

  stringstream ss;
  string s;
  String str;

  ss << std::bitset<sizeof(uint8_t) * CHAR_BIT>(hex_num);
  s = ss.str();
  str = s.c_str();

  return str;
}

uint16_t ConvertFromTwoBytes2DoubleByte(uint8_t byte_1, uint8_t byte_2) {
  uint8_t two_bytes[2] = {byte_1, byte_2};  // 1byteが２つ
  uint16_t double_byte = (two_bytes[0] << 8) | two_bytes[1];

  return double_byte;
}

bool EmergencySwitchState() {
  bool emergency_stop_switch_state;
  if (mcp.digitalRead(kIoExpanderEmergencyStopSwitch1) == LOW) {
    // Serial.println("Emergency switch on...");
    emergency_stop_switch_state = true;
  } else {
    emergency_stop_switch_state = false;
  }

  float state[] = {false};
  state[0] = emergency_stop_switch_state;
  // JsonGenerator(doc_4_debug, 1, "EmergencySwitchState", state);
  // SendJson(doc_4_debug, 0);
  // SendJson(doc_4_debug, 0);

  xQueueSend(queue_emergency_switch_state, &emergency_stop_switch_state, kRtosQueueTimeOut);

  return emergency_stop_switch_state;

}