#include <Arduino.h>
// motor driver pin No.
#define RightmbFree 53
#define RightAlarmReset 51
#define Rightm0 49
#define RightStopMode 47
#define RightAlarmOut 40
#define RightwngN 38
#define RightSpeedOut 36
#define RightFWD 33
#define RightREV 31
#define RightmmPin 3

#define LeftREV 45
#define LeftFWD 43
#define LeftmbFree 41
#define LeftAlarmReset 39
#define Leftm0 37
#define LeftStopMode 35
#define LeftSpeedOut 34
#define LeftwngN 32
#define LeftAlarmOutN 30
#define LeftmmPin 2

// cylinder pin No.
#define c1FWD 50
#define c1REV 52
#define c2FWD 46
#define c2REV 48

#define LOADCELL_PIN 22

// motor power relay
#define motor_power_relay 5  // pin No.5 relay switch

// propo
const int CH1 =  6;  // right horizontal = X
const int CH2 =  9;  // left vertical = Y
const int CH3 =  8;  // right vertical = Y
const int CH4 =  7;  // left horizontal = X
const int CH5 = 10;  // A  
const int CH6 = 11;  // B
const int CH7 = 12;  // C
const int CH8 = 13;  // D 

// calculation velocity to rpm
#define M_PI 3.14159265358979323846
float LINEAR_SPEED_MAX  = 0.46;
float ANGULAR_SPEED_MAX = 0.75;

// control variable
float g_linear_x;
float g_angular_z;
float g_cylinder_1;
float g_cylinder_2;
// calculate variable
float g_left_rpm;
float g_right_rpm;

// propo switch variable
int g_power_relay = 0;          // A : 0:on 1:off
int g_mode_switch = 0;          // none : 0:bucket mode 1:others mode
int g_select_controler = 2;     // C : 0:jetson 1:off 2:propo
int g_motor_brake = 1;          // none : 0:neutral 1:brake

float g_left_encoder;
float g_right_encoder;

// battery
// #define soc1 22    // pcb 4 DO4
// #define soc2 24    // pcb 3 DO5
// #define RedLED 16  // pcb 6
// #define BatteryPin A2

void receivePropoSwitch()
{
    int togle_A = pulseIn(CH5, HIGH); // down x2056/2057 (1510.5) up 963/x964
    // int togle_B = pulseIn(CH6, HIGH); // down x2056/2057 (1510) up 963/x964
    // int togle_C = pulseIn(CH7, HIGH); // down 2056/2057 (1785) middle 1507/1513 (1238.5) up 963/964
    // int togle_D = pulseIn(CH8, HIGH); // down x2056/2057 (1510) up 963/x964

    if (togle_A < 1510)
    {
        //up
        g_power_relay = 0;
    }
    else if (togle_A > 1510)
    {
        //down
        g_power_relay = 1;
    }

    // if (togle_B < 1510)
    // {
    //     //up
    //     g_motor_brake = 0;
    // }
    // else if (togle_B > 1510)
    // {
    //     //down
    //     g_motor_brake = 1;
    // }

    // if (togle_C < 1238)
    // {
    //     //up
    //     g_select_controler = 0;// jetson
    // }
    // else if (1238 < togle_C && togle_C < 1785)
    // {
    //     //middle
    //     g_select_controler = 1;// off
    // }
    // else if (togle_C > 1785)
    // {
    //     //down
    //     g_select_controler = 2;// propo
    // }

    // if (togle_D < 1510)
    // {
    //     //up
    //     g_mode_switch = 0;// bucket mode
    // }
    // else if (togle_D > 1510)
    // {
    //     //down
    //     g_mode_switch = 1;// others mode
    // }

    delay(50); // 50ms wait 1000/50 = 20Hz

    //---------------------------------- print for debug ----------------------------------
    // Serial.print(togle_A);
    // Serial.print(',');
    // Serial.print(togle_B);
    // Serial.print(',');
    // Serial.println(togle_C);
}

void receivePropoJoy()
{   // input proportional controler joysticks
    float input_propo_joy_leftY  = map(pulseIn(CH4, HIGH), 1917, 1103, -100, 100) /  100.0;    // left joy Y 
    float input_propo_joy_leftX  = map(pulseIn(CH2, HIGH), 1917, 1103, -100, 100) /  100.0;    // left joy X
    float input_propo_joy_rightY = map(pulseIn(CH3, HIGH), 1917, 1103, -100, 100) / -100.0;
    float input_propo_joy_rightX = map(pulseIn(CH1, HIGH), 1917, 1103, -100, 100) /  100.0;

    // dead zone
    if (-0.30 <= input_propo_joy_leftX && input_propo_joy_leftX <= 0.30 )
    {
        input_propo_joy_leftX = 0.00;
    }
    if (-0.30 <= input_propo_joy_leftY && input_propo_joy_leftY <= 0.30 )
    {
        input_propo_joy_leftY = 0.00;
    }

    if (-0.30 <= input_propo_joy_rightY && input_propo_joy_rightY <= 0.30 )
    {
        input_propo_joy_rightY = 0.00;
    }
    if (-0.30 <= input_propo_joy_rightX && input_propo_joy_rightX <= 0.30 )
    {
        input_propo_joy_rightX = 0.00;
    }

    g_linear_x  = input_propo_joy_leftY * LINEAR_SPEED_MAX;
    g_angular_z = input_propo_joy_leftX * ANGULAR_SPEED_MAX;
    g_cylinder_1 = input_propo_joy_rightY;
    g_cylinder_2 = input_propo_joy_rightX;

    //---------------------------------- print for debug ----------------------------------
    // Serial.print(input_propo_joy_leftY);
    // Serial.print(',');
    // Serial.print(input_propo_joy_leftX);
    // Serial.print(',');
    // Serial.print(input_propo_joy_rightX);
    // Serial.print(',');
    // Serial.print(input_propo_joy_rightY);
}

void receiveSerialFromJetson()
{
    String linear_x_str;
    String angular_z_str;
    String angular_x_str;
    String angular_y_str;
    // String linear_y_str;

    float linear_x;
    float angular_z;
    float cylinder_1;
    float cylinder_2;
    // int   linear_y;

    if (Serial.available() > 0)
    {
        String received_data = Serial.readStringUntil('\n');                                  // 改行までのデータを読み込む
        Serial.println(received_data);                                                        // データをシリアルモニターに表示

        int comma_index1 = received_data.indexOf(',');                                        // 1番目のカンマの位置を検索
        if (comma_index1 != -1)
        {
            linear_x_str = received_data.substring(0, comma_index1);                            // 1番目の部分文字列を取得
            int comma_index2 = received_data.indexOf(',', comma_index1 + 1);                  // 2番目のカンマの位置を検索
            if (comma_index2 != -1)
            {
                angular_z_str = received_data.substring(comma_index1 + 1, comma_index2);                      // 2番目の部分文字列を取得
                int comma_index3 = received_data.indexOf(',', comma_index2 + 1);              // 3番目のカンマの位置を検索
                if (comma_index3 != -1)
                {
                    angular_x_str = received_data.substring(comma_index2 + 1, comma_index3);   // 3番目の部分文字列を取得
                    angular_y_str = received_data.substring(comma_index3 + 1);                // 4番目の部分文字列を取得
                }
                else
                {   
                    // Serial.println("Error: Less than 2 commas in the inputString.");            // カンマが3つ未満の場合のエラーハンドリング
                }
            }
            else
            {
                // Serial.println("Error: Less than 2 commas in the inputString.");                // カンマが2つ未満の場合のエラーハンドリング
            }
        }
        else
        {
            // Serial.println("Error: No comma found in the inputString.");                        // カンマが見つからない場合のエラーハンドリング
        }

        linear_x   = linear_x_str.toFloat();
        angular_z  = angular_z_str.toFloat();
        cylinder_1 = angular_y_str.toFloat();
        cylinder_2 = angular_x_str.toFloat();
        // power_relay = linear_y_str.toInt();

        g_linear_x  = linear_x;
        g_angular_z = angular_z;
        g_cylinder_1 = cylinder_1;
        g_cylinder_2 = cylinder_2;
        // g_power_relay_jetson = power_relay;
    }
    else
    {
        // Serial.println("No data");
        g_linear_x  = 0.0;
        g_angular_z = 0.0;
        g_cylinder_1 = 0.0;
        g_cylinder_2 = 0.0;
    }
    //---------------------------------- print for debug ----------------------------------
    // Serial.print("linear.x: ");
    // Serial.print(linear_x);
    // Serial.print(",");
    // Serial.print(" angular.z: ");
    // Serial.print(angular_z);
    // Serial.print(",");
    // Serial.print(" cylinder_1: ");
    // Serial.print(cylinder_1);
    // Serial.print(",");
    // Serial.print(" cylinder_2: ");
    // Serial.println(cylinder_2);
    //---------------------------------- print for debug ----------------------------------
}

void sendSerialToJetson(int left, int right)
{
    Serial.print(left);
    Serial.print(",");
    Serial.print(right);
    Serial.println();
    delay(20);
}

float velToRpm(float v)
{
    // convert velocity to rpm
    const float REDUCTION_RATIO = 100.0;  // 減速比 reduction ratio
    const float WHEEL_RADIUS = 0.1105;  // 車輪半径 radius of gyration [m]
    float n = 30 / M_PI * REDUCTION_RATIO / WHEEL_RADIUS * v;

    return n;
}

void ik(float v, float w)
{
    // calculate linear velocity and angur velocity to 
    // left and right velocity
    float WHEEL_DISTANCE = 0.600;     // 車輪間距離 distance between the wheels [m]
    float v_l = v - WHEEL_DISTANCE * w;
    float v_r = v + WHEEL_DISTANCE * w;

    float left_rpm  = velToRpm(v_l);
    float right_rpm = velToRpm(v_r);

    //---------------------------------- print for debug ----------------------------------
    // Serial.print("velocity:");
    // Serial.print(v);
    // Serial.print(',');
    // Serial.print(w);
    // Serial.print("rpm:");
    // Serial.print(left_rpm);
    // Serial.print(',');
    // Serial.println(right_rpm);
    //---------------------------------- print for debug ----------------------------------

    // direction of motor
    if(left_rpm > 0)
    {
        digitalWrite(LeftFWD, HIGH);
        digitalWrite(LeftREV, LOW);
        // Serial.print("Left dir:FWD, ");

    }
    else if (left_rpm < 0)
    {
        digitalWrite(LeftREV, HIGH);
        digitalWrite(LeftFWD, LOW);
        // Serial.print("Left dir:REV, ");
    }
    else{
        digitalWrite(LeftFWD, LOW);
        digitalWrite(LeftREV, LOW);
        // Serial.print("Left dir:stop, ");
    }

    if(right_rpm > 0)
    {
        digitalWrite(RightFWD, HIGH);
        digitalWrite(RightREV, LOW); // モータの向きが逆だから，REVが前進方向
        // Serial.print("Right dir:FWD, ");
    }
    else if (right_rpm < 0)
    {
        digitalWrite(RightFWD, LOW);
        digitalWrite(RightREV, HIGH);
        // Serial.print("Right dir:REV, ");
    }
    else
    {
        digitalWrite(RightFWD, LOW);
        digitalWrite(RightREV, LOW);
        // Serial.print("Right dir:stop, ");
    }

    if (g_mode_switch == 1)
    {
        if (left_rpm < 0 || right_rpm < 0)
        {
            g_left_rpm  = right_rpm;
            g_right_rpm = left_rpm;
        }
        else
        {
            g_left_rpm  = left_rpm;
            g_right_rpm = right_rpm;
        }
    }
    else if (g_mode_switch == 0)
    {
        if (left_rpm > 0 || right_rpm > 0)
        {
            g_left_rpm  = right_rpm;
            g_right_rpm = left_rpm;
        }
        else
        {
            g_left_rpm  = left_rpm;
            g_right_rpm = right_rpm;
        }
    }
}

void stopMotor()
{
    analogWrite(LeftmmPin, 0);
    analogWrite(RightmmPin, 0);

    if (g_motor_brake == 0)
    {
        // HIGH:ブレーキ解放 LOW:ブレーキ保持
        digitalWrite(LeftmbFree, HIGH);
        digitalWrite(RightmbFree, HIGH);
        // Serial.print("Neutral, ");
    }
    else if (g_motor_brake == 1)
    {
        // HIGH:ブレーキ解放 LOW:ブレーキ保持
        digitalWrite(LeftmbFree, LOW);
        digitalWrite(RightmbFree, LOW);
        // Serial.print("Brake, ");
    }

    //=== STOP表示 ===
    // Serial.print("Motor stop, ");
}

void driveMotor(int left_rpm, int right_rpm)
{
    int left_vol;
    int right_vol;

    //---------------------------------- print for debug ----------------------------------
    // Serial.print(left_rpm);
    // Serial.print(',');
    // Serial.print(right_rpm);
    // Serial.print(',');
    //---------------------------------- print for debug ----------------------------------


    left_rpm  = abs(left_rpm);
    right_rpm = abs(right_rpm);

    left_rpm = min(left_rpm, 4000);
    left_rpm = max(left_rpm, 0);

    right_rpm = min(right_rpm, 4000);
    right_rpm = max(right_rpm, 0);

    //---------------------------------- print for debug ----------------------------------
    // Serial.print(left_rpm);
    // Serial.print(',');
    // Serial.print(right_rpm);
    // Serial.print(',');
    //---------------------------------- print for debug ----------------------------------

    left_vol  = map(left_rpm, 0, 4000, 0, 255);
    right_vol = map(right_rpm, 0, 4000, 0, 255);

    if(left_vol && right_vol == 0.0)
    {
        stopMotor();
    }
    else
    {
        analogWrite(LeftmmPin, left_vol);
        analogWrite(RightmmPin, right_vol);
    }

    //---------------------------------- print for debug ----------------------------------
    // Serial.print(left_vol);
    // Serial.print(",");
    // Serial.println(right_vol);
    //---------------------------------- print for debug ----------------------------------
}

void moveCylinder(float input_value, int FWD, int REV)
{
    //---------------------------------- print for debug ----------------------------------
    // Serial.println(input_value);
    // Serial.print(input_value);
    if(input_value >= 0.5)
    {
        // Serial.println("Extend");
        digitalWrite(FWD, HIGH);
        digitalWrite(REV, LOW);
    }
    else if (input_value <= -0.5)
    {
        // Serial.println("Retract");
        digitalWrite(FWD, LOW);
        digitalWrite(REV, HIGH);
    }
    else
    {
        digitalWrite(FWD, LOW);
        digitalWrite(REV, LOW);
        // Serial.println("cylinder stop");
    }
}

void stopCylinder(int c1f, int c1r, int c2f, int c2r)
{
    digitalWrite(c1f, LOW);
    digitalWrite(c1r, LOW);
    digitalWrite(c2f, LOW);
    digitalWrite(c2r, LOW);
    
    // Sample for additional cylinder, Add argument ", int c3f, int c3r"
    // digitalWrite(c3f, LOW);
    // digitalWrite(c3r, LOW);
    
    // STOP表示
    // Serial.print("stop cylinder , ");
}

void loadCell()
{
    // int load_cell = analogRead(LOADCELL_PIN);
    // Serial.print(load_cell);
}

void setup()
{
    Serial.begin(115200);
    //右モータードライバーアウトプット
    pinMode(RightFWD, OUTPUT);
    pinMode(RightREV, OUTPUT);
    pinMode(RightStopMode, OUTPUT);
    pinMode(Rightm0, OUTPUT);
    pinMode(RightAlarmReset, OUTPUT);
    pinMode(RightmbFree, OUTPUT);
    //右モータードライバーインプット
    pinMode(RightAlarmOut, INPUT);
    pinMode(RightwngN, INPUT);
    pinMode(RightSpeedOut, INPUT);

    //左モータードライバーアウトプット
    pinMode(LeftFWD, OUTPUT);
    pinMode(LeftREV, OUTPUT);
    pinMode(LeftStopMode, OUTPUT);
    pinMode(Leftm0, OUTPUT);
    pinMode(LeftAlarmReset, OUTPUT);
    pinMode(LeftmbFree, OUTPUT);
    //左モータードライバーインプット
    pinMode(LeftAlarmOutN, INPUT);
    pinMode(LeftwngN, INPUT);
    pinMode(LeftSpeedOut, INPUT);

    // HIGH:速度指定を外部入力 LOW:内部速度設定器
    digitalWrite(Rightm0, HIGH);
    digitalWrite(Leftm0, HIGH); 
    //モータードライバー速度設定
    pinMode(LeftmmPin, OUTPUT);
    pinMode(RightmmPin, OUTPUT);
    // HIGH:時間設定 LOW:瞬時停止
    digitalWrite(RightStopMode, LOW);
    digitalWrite(LeftStopMode, LOW);
    // HIGH:ブレーキ解放 LOW:ブレーキ保持
    digitalWrite(RightmbFree, HIGH);
    digitalWrite(LeftmbFree, HIGH);


    // シリンダーモータードライバー
    pinMode(c1FWD, OUTPUT);
    pinMode(c1REV, OUTPUT);
    pinMode(c2FWD, OUTPUT);
    pinMode(c2REV, OUTPUT);
    // アームフィードバック
    // pinMode(LiftFB, INPUT);
    // pinMode(DumpFB, INPUT);

    // レシーバー
    pinMode(CH1, INPUT);
    pinMode(CH3, INPUT);
    pinMode(CH2, INPUT);
    pinMode(CH4, INPUT);
    pinMode(CH5, INPUT);
    pinMode(CH6, INPUT);
    pinMode(CH7, INPUT);

    pinMode(motor_power_relay, OUTPUT); // 動力リレー用リレー
    pinMode(LOADCELL_PIN, INPUT); // ロードセル
}

void loop()
{
    float linear_x;
    float angular_z;

    receivePropoSwitch();

    switch (g_select_controler)
    {
    case 0:
        receiveSerialFromJetson();
        // Serial.println("Current mode: Jetson");
        break;
    case 1:
        stopMotor();
        stopCylinder(c1FWD, c1REV, c2FWD, c2REV);
        // Serial.println("Current mode: no data");
        break;
    case 2:
        receivePropoJoy();
        // Serial.println("Current mode: Propo");
        break;
    }


    if (g_power_relay == 0)
    {
        // digitalWrite(motor_power_relay, HIGH);
        // Serial.println("Power relay: ON");
        
        stopMotor();
        stopCylinder(c1FWD, c1REV, c2FWD, c2REV);
    } 
    else if (g_power_relay == 1)
    {
        // if (g_power_relay_jetson == 0)
        // {
        //     digitalWrite(motor_power_relay, HIGH);
        //     // Serial.println("Power relay: ON");

        //     stopMotor();
        //     stopCylinder(c1FWD, c1REV, c2FWD, c2REV);
        // }
        // else if (g_power_relay_jetson == 1)
        // {
        // digitalWrite(motor_power_relay, LOW);
        // Serial.println("Power relay: OFF");

        if (g_mode_switch == 0)
        {
            linear_x  = - g_linear_x;
            angular_z = g_angular_z;
        }
        else if (g_mode_switch == 1)
        {
            linear_x  = g_linear_x;
            angular_z = g_angular_z;
        }

        // calcurate machine speed to motor rpm
        ik(linear_x, angular_z);

        // rotate each motor
        driveMotor(g_left_rpm, g_right_rpm);

        // cylinder　動作を逆にするには符号を反転させる
        moveCylinder(-g_cylinder_1, c1FWD, c1REV);    // arm    -:retact +:extend
        moveCylinder(-g_cylinder_2, c2FWD, c2REV);    // bucket -:retact +:extend
        // }
    }

    // loadCell();

    // === send to jetson ===
    g_left_encoder  = g_left_rpm;
    g_right_encoder = g_right_rpm;
    // sendSerialToJetson(g_left_encoder, g_right_encoder);

    //---------------------------------- print for debug switches ----------------------------------
    // Serial.println(g_select_controler);
    // Serial.println(g_safety_switch);
    // Serial.println(g_mode_switch);
    //---------------------------------- print for debug variables ----------------------------------
    // Serial.print(linear_x);
    // Serial.print(',');
    // Serial.println(angular_z);
    // Serial.print(", ");

    // Serial.print(g_left_rpm);
    // Serial.print(',');
    // Serial.print(g_right_rpm);
    // Serial.print(',');

    // Serial.print(g_linear_x);
    // Serial.print(',');
    // Serial.print(g_angular_z);
    // Serial.print(',');
    // Serial.print(g_cylinder_1);
    // Serial.print(',');
    // Serial.println(g_cylinder_2);
}