#include <Adafruit_NeoPixel.h>
#include <Arduino.h>

#include <bitset>
#include <sstream>

#include "driver/gpio.h"
#include "driver/twai.h"

const gpio_num_t kCylinder1Forward = GPIO_NUM_15;
const gpio_num_t kCylinder1Reverse = GPIO_NUM_16;
const gpio_num_t kCylinder2Forward = GPIO_NUM_17;
const gpio_num_t kCylinder2Reverse = GPIO_NUM_18;
const gpio_num_t kCylinder1Feedback = GPIO_NUM_19;
const gpio_num_t kCylinder2Feedback = GPIO_NUM_2;

const gpio_num_t kPowerRelay = GPIO_NUM_1;
const gpio_num_t kEmergencyStopSwitch1 = GPIO_NUM_11;
const gpio_num_t kEmergencyStopSwitch2 = GPIO_NUM_12;

const gpio_num_t kPatliteRedLight = GPIO_NUM_8;
const gpio_num_t kPatliteGreenLight = GPIO_NUM_21;
const gpio_num_t kPatliteYellowLight = GPIO_NUM_47;
const gpio_num_t kPatliteRedFlash = GPIO_NUM_10;
const gpio_num_t kPatliteYellowFlash = GPIO_NUM_9;

const gpio_num_t kUart1Tx = GPIO_NUM_7;  // UART1: Main
const gpio_num_t kUart1RX = GPIO_NUM_6;
const gpio_num_t kUart2Tx = GPIO_NUM_5;  // UART2: Jetson
const gpio_num_t kUart2RX = GPIO_NUM_4;

const gpio_num_t kCanTx = GPIO_NUM_35;
const gpio_num_t kCanRx = GPIO_NUM_36;

const int kDebugRate = 115200;
const int kUart1Rate = 4800;
const int kUart2Rate = 4800;

const TickType_t kCanTimeOut = pdMS_TO_TICKS(500);  // Unit: milliseconds
const uint32_t kCylinder1CanId = 0x200;
const uint32_t kCylinder2CanId = 0x201;
const uint32_t kPowerReleyCanId = 0x202;
const uint32_t kMsdStateCanId = 0x203;
const uint32_t kCylinder1FeedbackCanId = 0x204;
const uint32_t kCylinder2FeedbackCanId = 0x205;

float g_cylinder_1;
float g_cylinder_2;

void MoveCylinder(float input_value, gpio_num_t gpio_forward, gpio_num_t gpio_reverse);
void StopCylinder(gpio_num_t gpio_cylinder1_forward, gpio_num_t gpio_cylinder1_reverse, gpio_num_t gpio_cylinder2_forward, gpio_num_t gpio_cylinder2_reverse);
void CanTransmitter(uint32_t identifier, uint32_t extd, uint8_t uart_data[]);
twai_message_t CanReceiver(uint32_t identifier);

bool Patlite(String color, String mode, bool flag);

int confirmEmergencyStop();
String ConvertFromHex2Bin(uint8_t hex_num);

float cylinder_1 = 0;
float cylinder_2 = 0;
int power_relay = 0;
int msd_state = 4;

void setup() {
  // GPIO mode init
  gpio_set_direction(kCylinder1Forward, GPIO_MODE_OUTPUT);
  gpio_set_direction(kCylinder1Reverse, GPIO_MODE_OUTPUT);
  gpio_set_direction(kCylinder2Forward, GPIO_MODE_OUTPUT);
  gpio_set_direction(kCylinder2Reverse, GPIO_MODE_OUTPUT);
  gpio_set_direction(kPowerRelay, GPIO_MODE_OUTPUT);
  gpio_set_direction(kEmergencyStopSwitch1, GPIO_MODE_INPUT);
  gpio_set_direction(kEmergencyStopSwitch2, GPIO_MODE_INPUT);
  gpio_set_direction(kPatliteRedLight, GPIO_MODE_OUTPUT);
  gpio_set_direction(kPatliteGreenLight, GPIO_MODE_OUTPUT);
  gpio_set_direction(kPatliteYellowLight, GPIO_MODE_OUTPUT);
  gpio_set_direction(kPatliteRedFlash, GPIO_MODE_OUTPUT);
  gpio_set_direction(kPatliteYellowFlash, GPIO_MODE_OUTPUT);

  gpio_set_direction(kCylinder1Feedback, GPIO_MODE_INPUT);
  gpio_set_direction(kCylinder2Feedback, GPIO_MODE_INPUT);

  // GPIO pullup or pulldown
  while (gpio_pulldown_en(kEmergencyStopSwitch1) != ESP_OK);
  while (gpio_pulldown_en(kEmergencyStopSwitch2) != ESP_OK);

  digitalWrite(kPatliteRedLight, LOW);
  digitalWrite(kPatliteRedFlash, LOW);
  digitalWrite(kPatliteYellowLight, LOW);
  digitalWrite(kPatliteYellowFlash, LOW);
  digitalWrite(kPatliteGreenLight, LOW);

  // Serial init
  Serial.begin(kDebugRate);
  while (!Serial);
  Serial1.begin(kUart1Rate, SERIAL_8E1, kUart1Tx, kUart1RX);
  while (!Serial1);

  // CAN init
  twai_general_config_t g_config = TWAI_GENERAL_CONFIG_DEFAULT(kCanTx, kCanRx, TWAI_MODE_NORMAL);
  twai_timing_config_t t_config = TWAI_TIMING_CONFIG_250KBITS();  // CAN Rate Setting: SCiBのレートに設定
  twai_filter_config_t f_config = TWAI_FILTER_CONFIG_ACCEPT_ALL();

  while (!twai_driver_install(&g_config, &t_config, &f_config) == ESP_OK);

  Serial.println("===== Start Program =====");
}

void loop() {
  esp_err_t result;

  result = twai_start();
  if (result != ESP_OK) {
    Serial.printf("twai_start(): ERROR\n");
    while (1);
  }

  twai_message_t message_receive;

  result = twai_receive(&message_receive, kCanTimeOut);
  if (result == ESP_OK) {
    switch (message_receive.identifier) {
      case kCylinder1CanId:
        memcpy(&cylinder_1, message_receive.data, sizeof(float));
        // Serial.printf("Cylinder1 -----> %f\n", cylinder_1);
        break;
      case kCylinder2CanId:
        memcpy(&cylinder_2, message_receive.data, sizeof(float));
        // Serial.printf("Cylinder2 -----> %f\n", cylinder_2);
        break;
      case kPowerReleyCanId:
        memcpy(&power_relay, message_receive.data, sizeof(int));
        // Serial.printf("PowerRelay -----> %d\n", power_relay);
        break;
      case kMsdStateCanId:
        memcpy(&msd_state, message_receive.data, sizeof(int));
        // Serial.printf("MsdState -----> %d\n", msd_state);
        break;
      default:
        // printf("other ID...\n");
        break;
    }
  } else if (result == ESP_ERR_TIMEOUT) {
    printf("ESP_ERR_TIMEOUT: twai_receive()\n");
  } else if (result == ESP_ERR_INVALID_ARG) {
    printf("ESP_ERR_INVALID_ARG: twai_receive()\n");
  } else if (result == ESP_ERR_INVALID_STATE) {
    printf("ESP_ERR_INVALID_STATE: twai_receive()\n");
  } else {
    printf("ERORR...\n");
  }

  switch (power_relay) {
    case 0:
      digitalWrite(kPowerRelay, LOW);
      // Serial.println("Relay Off...\n");
      break;
    case 1:
      digitalWrite(kPowerRelay, HIGH);
      // Serial.println("Relay On...\n");
      break;
    default:
      break;
  }

  switch (msd_state) {
    case 0: // 自動/バックホウ
      digitalWrite(kPatliteGreenLight, LOW);
      digitalWrite(kPatliteRedLight, LOW);
      digitalWrite(kPatliteYellowLight, HIGH);
      break;
    case 1: // 手動操作 propo
      digitalWrite(kPatliteGreenLight, HIGH);
      digitalWrite(kPatliteRedLight, LOW);
      digitalWrite(kPatliteYellowLight, LOW);
      break;
    case 2: // 停止
      digitalWrite(kPatliteGreenLight, LOW);
      digitalWrite(kPatliteRedLight, HIGH);
      digitalWrite(kPatliteYellowLight, LOW);
      break;
    // case 3: // バッテリ残量少 自動/バックホウ
    //   digitalWrite(kPatliteGreenLight, LOW);
    //   digitalWrite(kPatliteRedLight, HIGH);
    //   digitalWrite(kPatliteYellowLight, HIGH);
    //   // delay(2000);
    //   // digitalWrite(kPatliteRedLight, LOW);
    //   break;
    // case 4: // バッテリ残量少 puroprtional
    //   digitalWrite(kPatliteGreenLight, HIGH);
    //   digitalWrite(kPatliteRedLight, HIGH);
    //   digitalWrite(kPatliteYellowLight, LOW);
    //   // delay(2000);
    //   // digitalWrite(kPatliteRedLight, LOW);
    //   break;
    default:
      digitalWrite(kPatliteGreenLight, HIGH);
      digitalWrite(kPatliteRedLight, HIGH);
      digitalWrite(kPatliteYellowLight, HIGH);
      break;
  }

  if (message_receive.identifier == kCylinder1CanId) {
    MoveCylinder(cylinder_1, kCylinder1Forward, kCylinder1Reverse);
    int cylinder_feedback1 = analogRead(kCylinder1Feedback);
    uint8_t cylinder_feedback1_can[sizeof(int)];
    memcpy(cylinder_feedback1_can, &cylinder_feedback1, sizeof(int));
    CanTransmitter(kCylinder1FeedbackCanId, 0, cylinder_feedback1_can);
    // Serial.printf("Cylinder1 FB -----> %d\n", cylinder_feedback1);
  }
  if (message_receive.identifier == kCylinder2CanId) {
    
    MoveCylinder(cylinder_2, kCylinder2Reverse, kCylinder2Forward);
    Serial.printf("Cylinder2 -----> %f\n", cylinder_2);
    int cylinder_feedback2 = analogRead(kCylinder2Feedback);
    uint8_t cylinder_feedback2_can[sizeof(int)];
    memcpy(cylinder_feedback2_can, &cylinder_feedback2, sizeof(int));
    CanTransmitter(kCylinder2FeedbackCanId, 0, cylinder_feedback2_can);
    // Serial.printf("Cylinder2 FB -----> %d\n", cylinder_feedback2);
  }

  result = twai_stop();
  if (result != ESP_OK) {
    Serial.printf("twai_stop(): ERROR\n");
    while (1);
  }
}

void MoveCylinder(float input_value, gpio_num_t gpio_forward, gpio_num_t gpio_reverse) {
  if (input_value >= 0.5) {
    digitalWrite(gpio_forward, HIGH);
    digitalWrite(gpio_reverse, LOW);
    // Serial.println("-----> Forward\n");
  } else if (input_value <= -0.5) {
    digitalWrite(gpio_forward, LOW);
    digitalWrite(gpio_reverse, HIGH);
    // Serial.println("-----> Reverse\n");
  } else {
    digitalWrite(gpio_forward, LOW);
    digitalWrite(gpio_reverse, LOW);
  }
}

void StopCylinder(gpio_num_t gpio_cylinder1_forward, gpio_num_t gpio_cylinder1_reverse, gpio_num_t gpio_cylinder2_forward, gpio_num_t gpio_cylinder2_reverse) {
  digitalWrite(gpio_cylinder1_forward, LOW);
  digitalWrite(gpio_cylinder1_reverse, LOW);
  digitalWrite(gpio_cylinder2_forward, LOW);
  digitalWrite(gpio_cylinder2_reverse, LOW);
}

void CanTransmitter(uint32_t identifier, uint32_t extd, uint8_t send_data[]) {
  twai_message_t message_transmit;
  message_transmit.identifier = identifier;
  message_transmit.extd = extd;
  message_transmit.data_length_code = sizeof(&send_data) / sizeof(uint8_t);
  message_transmit.flags = TWAI_MSG_FLAG_NONE;

  for (size_t i = 0; i < message_transmit.data_length_code; i++) {
    message_transmit.data[i] = send_data[i];
  }

  twai_transmit(&message_transmit, kCanTimeOut);

  Serial.printf("\n++++++++++ CAN CONTENTS ++++++++++\n");

  Serial.printf("identifier: %x\n", message_transmit.identifier);
  Serial.printf("extd: %u\n", message_transmit.extd);
  Serial.printf("data_length_code: %u\n", message_transmit.data_length_code);
  for (size_t i = 0; i < message_transmit.data_length_code; i++) {
    Serial.printf("data%d: %u\n", i, message_transmit.data[i]);
  }

  Serial.printf("\n++++++++++++++++++++++++++++++++\n");
}

twai_message_t CanReceiver(uint32_t identifier) {
  twai_message_t message_receive;

  if (twai_receive(&message_receive, kCanTimeOut) == ESP_OK && message_receive.identifier == identifier) {
    return message_receive;
  } else {
    printf("missed receive...\n");
  }
}

int confirmEmergencyStop() {
  // Returns the number of the switch pressed

  if (digitalRead(kEmergencyStopSwitch1) == LOW) {
    digitalWrite(kPowerRelay, HIGH);
    Serial.println("Emergency switch 1 off...");
  } else if (digitalRead(kEmergencyStopSwitch1) == HIGH) {
    Serial.println("Emergency switch 1 on...");
    digitalWrite(kPowerRelay, LOW);
  }

  if (digitalRead(kEmergencyStopSwitch2) == LOW) {
    digitalWrite(kPowerRelay, HIGH);
    Serial.println("Emergency switch 2 off...");
  } else if (digitalRead(kEmergencyStopSwitch2) == HIGH) {
    Serial.println("Emergency switch 2 on...");
    digitalWrite(kPowerRelay, LOW);
  }

  return 0;
}

bool Patlite(String color, String mode, bool flag) {
  if (color == "Red") {
    if (mode == "Flash") {
      if (flag) {
        digitalWrite(kPatliteRedLight, LOW);
        digitalWrite(kPatliteRedFlash, LOW);
        flag = false;
      } else {
        digitalWrite(kPatliteRedLight, HIGH);
        digitalWrite(kPatliteRedFlash, HIGH);
        flag = true;
        Serial.println("Red on...");
      }
    } else if (mode == "Light") {
      if (flag) {
        digitalWrite(kPatliteRedLight, LOW);
        flag = false;
      } else {
        digitalWrite(kPatliteRedLight, HIGH);
        flag = true;
        Serial.println("Red on...");
      }
    }
  } else if (color == "Green") {
    if (mode == "Flash") {
      Serial.println("Function is nothing...");
    } else if (mode == "Light") {
      if (flag) {
        digitalWrite(kPatliteGreenLight, LOW);
        flag = false;
      } else {
        digitalWrite(kPatliteGreenLight, HIGH);
        flag = true;
        Serial.println("Green on...");
      }
    }
  } else if (color == "Yellow") {
    if (mode == "Flash") {
      if (flag) {
        digitalWrite(kPatliteYellowLight, LOW);
        digitalWrite(kPatliteYellowFlash, LOW);
        flag = false;
      } else {
        digitalWrite(kPatliteYellowLight, HIGH);
        digitalWrite(kPatliteYellowFlash, HIGH);
        flag = true;
        Serial.println("Yellow on...");
      }
    } else if (mode == "Light") {
      if (flag) {
        digitalWrite(kPatliteYellowLight, LOW);
        flag = false;
      } else {
        digitalWrite(kPatliteYellowLight, HIGH);
        flag = true;
        Serial.println("Yellow on...");
      }
    }
  }

  return flag;
}

String ConvertFromHex2Bin(uint8_t hex_num) {
  using namespace std;

  stringstream ss;
  string s;
  String str;

  ss << std::bitset<sizeof(uint8_t) * CHAR_BIT>(hex_num);
  s = ss.str();
  str = s.c_str();

  return (str);
}