from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='msd_remote',
            executable='remote_twist_main_board',
            output='screen'
        ),
        Node(
            package='msd_remote',
            executable='remote_twist_websocket',
            output='screen'
        ),
    ])