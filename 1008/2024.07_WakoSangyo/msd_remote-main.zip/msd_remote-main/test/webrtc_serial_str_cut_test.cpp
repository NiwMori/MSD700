// 単体テスト
// 1. シリアルデータを受信する

#include <iostream>
#include <memory>
#include <string>

#include <functional>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include <regex>

void serial_catch(std::string dummy_data)
{   
    int recv_data = sizeof(dummy_data);

    if (recv_data > 0)
    {
        std::string tmp_serial_data;
        std::string convert_serial_data;

        tmp_serial_data += std::string(dummy_data.begin(), dummy_data.end());
        std::cout << "Raw:" << tmp_serial_data << std::endl;

        std::string input = tmp_serial_data;
        std::regex re("\\{[^{}]*\\}");
        std::smatch match;
 
        if (std::regex_search(input, match, re)) {
            std::cout << "Matched: " << match.str() << std::endl;
        }
        convert_serial_data = match.str();
 
        std::cout << "conv: " << convert_serial_data << std::endl;
    }
    else
    {
        std::cout << "serial not catched" << std::endl;
    }
}

int main(){
    // std::string json = (R"(
    //     {"linear_x":0, "angular_z":0, "cylinder_1":0, "cylinder_2":0, "power_relay":1} r_relay" :1}
    //     I_relay" :1}
    //     {"linear_x":0, "angular_z":0, "cylinder_1":0, "cylinder_2":0, "poweinder_2" :0, "power_relay":
    //     {"linear_x":0, "angular_z":0, "cylinder_1":0, "cylinder_2":0, "power_relay":1} {"linear_x":0, "angular_z":0, "cylinder_1":0, "cylinder_2":0, "power_relay":1} linder_1":0, "cylinder_2":0, "power_relay":1} I_relay":1}
    //     inder_2":0, "power_relay" :1}
    //     {"linear_x":0, "angular_z":0, "cylinder_1":0, "cylinder_2":0, "power_relay":1} inder_2":0, "power_relay":1} inder_2" :0, "power_relay":1} r_relay" :1}
    //     r_relay" :1}
    //     linder_1":0, "cylinder_2":0, "power_relay" :1} {"linear_x":0, "angular_z":0, "cylinder_1":0, "cylinder_2":0, "power_relay":1} inder_2" :0, "power_relay":1} r_relay" :1}
    //     inder_2":0, "power_relay":1} r_relay":1}
    //     {"linear_x":0, "angular_z":0, "cylinder_1":0, "cylinder_2":0, "power_relay":1} {"linear_x":0, "angular_z":0, "cylinder_1":0, "cylinder_2":0, "power_relay":1} {"linear_x":0, "angular_z":0, "cylinder_1":0, "cylinder_2":0, "power_relay":1} angular_z":0, "cyinder_2":0, "power_relay":1}
    //     {"linear_x":0, "angular_z":0, "cylinder_1":0, "cylinder_2":0, "power_relay":1} {"linear_x":0, "angular_z":0, "cylinder_1":0, "cylinder_2":0, "power_relay":1} inder_2":0, "power_relay":1} _relay": 1} linder_1":0, "cylinder_2":0, "power_relay":1} r_relay" :1}
    //     {"linear_x":0, "angular_z":0, "cylinder_1":0, "cylinder_2":0, "power_relay":1} inder_2":0, "power_relay":1}
    //     I_relay" :1}
    //     inder_
    //     _2" :0, "power_relay":1} inder_2" :0, "power_relay":1}
    //     {"linear_x":0, "angular_z":0, "cylinder_1":0, "cylinder_2":0, "power_relay":1} inder_2" :0, "power_relay":1} linder_1":0, "cylinder_2":0, "power_relay":1}
    //     {"linear_x":0, "angular_z":0, "cylinder_1":0, "cylinder_2":0, "power_relay":1} inder_2" :0, "power_relay":1} inder_2":0, "power_relay":1} inder_2":0, "power_relay" :1} r_relay": 1}
    //     {"linear_x":0, "angular_z":0, "cylinder_1":0, "cylinder_2":0, "power_relay" :1} {"linear_x":0,
    //     "angular_z":0, "cylinder_1":0, "cylinder_
    //     2": 0, "power_relay": 1}
    //     )"
    // );
    std::string dummy_data_case1 = R"(
        _2" :0, "power_relay":1} inder_2" :0, "power_relay":1}
        {"linear_x":0, "angular_z":0, "cylinder_1":0, "cylinder_2":0, "power_relay":1}inder_2" :0, "power_relay":1} linder_1":0, "cylinder_2":0, "power_relay":1}
    )";
    std::string dummy_data_case2 = R"(
        {"linear_x":0, "angular_z":0, "cylinder_1":0, "cylinder_2":0, "power_relay":1}inder_2" :0, "power_relay":1} inder_2":0, "power_relay":1} inder_2":0, "power_relay" :1} r_relay": 1}
        {"linear_x":0, "angular_z":0, "cylinder_1":0, "cylinder_2":0, "power_relay" :1}{"linear_x":0,
    )";
    std::string dummy_data_case3 = R"(
        "angular_z":0, "cylinder_1":0, "cylinder_
        2": 0, "power_relay": 1}
        {"linear_x":0, "angular_z":0, "cylinder_1":0, "cylinder_2":0, "power_relay" :1}
    )";

    std::string dummy_data_correct = R"(
        `0x02`{"linear_x":0, "angular_z":0, "cylinder_1":0, "cylinder_2":0, "power_relay" :1}]`\n`
    )";

    std::cout << "=== error case1 ===" << std::endl;
    serial_catch(dummy_data_case1);

    std::cout << "=== error case2 ===" << std::endl;
    serial_catch(dummy_data_case2);

    std::cout << "=== error case3 ===" << std::endl;
    serial_catch(dummy_data_case3);

    std::cout << "=== correct case ===" << std::endl;
    serial_catch(dummy_data_correct);


    return 0;
}