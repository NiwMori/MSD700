#include <iostream>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include <regex>


class SerialCommunication 
{
  public:
    SerialCommunication()
    {
        // std::cout << "serial start:" << std::endl; 
        openSerial("/tmp/ttyDataChannel1"); 
    }
    
    void openSerial(const char *device_name)
    {
        fd_ = open(device_name, O_RDWR | O_NOCTTY | O_NONBLOCK);
        // std::cout << "serial open attempt: " << fd_ << std::endl;
        
        fcntl(fd_, F_SETFL, 0);
        struct termios conf_tio;
        tcgetattr(fd_, &conf_tio);
        
        speed_t BAUDRATE = B115200;
        cfsetispeed(&conf_tio, BAUDRATE);
        cfsetospeed(&conf_tio, BAUDRATE);

        conf_tio.c_lflag &= ~(ECHO | ICANON);

        conf_tio.c_cc[VMIN] = 0;
        conf_tio.c_cc[VTIME] = 0;

        tcsetattr(fd_, TCSANOW, &conf_tio);
    }

    int sendSerialCommand(const std::string& message)
    {   
        // std::cout << "fd_: " << fd_ << std::endl;
        int bytes_written = write(fd_, message.c_str(), message.length()); //書き込んだバイトを返す
        // std::cout << "bytes_written: " << bytes_written << std::endl;
        if (bytes_written < 0)
        {
            // std::cout << "Serial Faild: could not write" << std::endl;
            return 0;
        }
        else
        {
            return 1;
        }
    }
    
    std::string receiveSerialData()
    {
        char buf[1024] = {0};
        std::string recv_serial_data;
        memset(buf,0,sizeof(buf));
        int recv_data = read(fd_, buf, sizeof(buf));
        // std::cout << "recv_data " << recv_data << std::endl;
        
        if (recv_data > 0)
        {
            std::string recv_serial_data; // raw data
            std::string convert_serial_data; 

            // raw data 取り込み
            recv_serial_data += std::string(buf, sizeof(buf));
            std::cout << "Raw:" << recv_serial_data << std::endl;

            return recv_serial_data;
        }
        else
        {
            std::cout << "serial not catched" << std::endl;
            return recv_serial_data;
        }
    }
    
  private:
    int fd_;
};