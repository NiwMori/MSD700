# PlatformIOの使い方
#### [README](../README.md) / [基本設計書](基本設計書.md) / [詳細設計書](詳細設計書.md) / [PlatformIOの使い方](PlatformIOの使い方.md)
---

PlatformIOは，組み込み開発のための統合開発環境（IDE）であり，ArduinoやESP32などのマイコン向けのプロジェクトを簡単に管理できます．以下に，PlatformIOの基本的な使い方を説明します．

## インストール

### Visual Studio Codeのインストール
1. [Visual Studio Code](https://code.visualstudio.com/)をダウンロードしてインストールします．

### PlatformIOのインストール
1. Visual Studio Codeを開きます．
2. 左側の拡張機能アイコン（四角形が4つ並んだアイコン）をクリックします．
3. 検索バーに「PlatformIO」と入力し，PlatformIO IDEをインストールします．

## 新しいプロジェクトの作成

1. Visual Studio Codeを開きます．
2. 左側のPlatformIOアイコン（アリのアイコン）をクリックします．
3. 「New Project」をクリックします．
4. プロジェクト名，ボード（例：ESP32），フレームワーク（例：Arduino）を選択し，「Finish」をクリックします．

## コードの編集

1. `src`フォルダ内の`main.cpp`ファイルを開きます．
2. 必要なコードを記述します．例えば，LEDを点滅させるコードは以下の通りです：

```cpp
#include <Arduino.h>

const int ledPin = 13;

void setup() {
  pinMode(ledPin, OUTPUT);
}

void loop() {
  digitalWrite(ledPin, HIGH);
  delay(1000);
  digitalWrite(ledPin, LOW);
  delay(1000);
}
```

## マイコンへの接続と書き込み

### マイコンの接続
1. マイコン（例：ESP32）をUSBケーブルでPCに接続します．
2. 接続が確認できたら，Visual Studio Codeの左下にあるPlatformIOのステータスバーにマイコンのポートが表示されます．

### プロジェクトのビルド
1. 左側のPlatformIOアイコン（アリのアイコン）をクリックします．
2. 「Project Tasks」を展開し，「Build」をクリックします．
3. ビルドが成功すると，コンパイルされたバイナリが生成されます．

### マイコンへの書き込み
1. 「Project Tasks」から「Upload」をクリックします．
2. PlatformIOが自動的にマイコンに接続し，プログラムを書き込みます．
3. 書き込みが完了すると，マイコンが自動的にリセットされ，プログラムが実行されます．

### ビルドと書き込み
上記の方法以外にも，VSCode下部のチェックマークと右矢印マークがそれぞれビルドと書き込みが可能です．
![alt text](../figs/platformio_使い方.png)

### シリアルモニタの使用
1. マイコンからのデバッグ情報を確認するために，シリアルモニタを使用します．
2. 「Project Tasks」から「Monitor」をクリックします．
3. シリアルモニタが開き，マイコンからの出力が表示されます．

これで，PlatformIOを使用してマイコンにプログラムを書き込む基本的な手順が完了です．必要に応じて，コードを編集し，再度ビルドおよび書き込みを行ってください．



---
#### [README](../README.md) / [基本設計書](基本設計書.md) / [詳細設計書](詳細設計書.md) / [PlatformIOの使い方](PlatformIOの使い方.md)