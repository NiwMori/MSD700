#include <iostream>
#include <chrono>
#include <memory>
#include <string>
#include <functional>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include <regex>
#include <nlohmann/json.hpp>

#include "rclcpp/rclcpp.hpp"
#include "msd_msgs/msg/encoder.hpp"
#include "msd_msgs/msg/cylinder.hpp"
#include "msd_msgs/msg/switch.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "sensor_msgs/msg/imu.hpp"


using std::placeholders::_1;
using namespace std::chrono_literals;
using json = nlohmann::json;

class SerialCommunication;
json feed_back_data = {
    {"left_encoder" , 0},
    {"right_encoder" , 0},
    {"cylinder_1" , 0},
    {"cylinder_2" , 0},
    {"power_relay" , 0}
};
json command_data = {
    {"linear_x" , 0.00},       // singned float MAX 0.46
    {"angular_z" , 0.00},     // singned float MAX 0.75
    {"cylinder_1" , 0.00},   // singned float MAX 1.00
    {"cylinder_2" , 0.00},   // singned float MAX 1.00
    {"power_relay" , 1}       // bool
};


class SerialCommunication 
{
  public:
    SerialCommunication()
    {
        std::cout << "serial start:" << std::endl; 
        openSerial("/tmp/ttyDataChannel1"); 
    }
    
    void openSerial(const char *device_name)
    {
        fd_ = open(device_name, O_RDWR | O_NOCTTY | O_NONBLOCK);
        std::cout << "serial open attempt: " << fd_ << std::endl;
        
        fcntl(fd_, F_SETFL, 0);
        struct termios conf_tio;
        tcgetattr(fd_, &conf_tio);
        
        speed_t BAUDRATE = B115200;
        cfsetispeed(&conf_tio, BAUDRATE);
        cfsetospeed(&conf_tio, BAUDRATE);

        conf_tio.c_lflag &= ~(ECHO | ICANON);

        conf_tio.c_cc[VMIN] = 0;
        conf_tio.c_cc[VTIME] = 0;

        tcsetattr(fd_, TCSANOW, &conf_tio);
    }

    int sendSerialCommand(const std::string& message)
    {   
        std::cout << "fd_: " << fd_ << std::endl;
        int bytes_written = write(fd_, message.c_str(), message.length()); //書き込んだバイトを返す
        std::cout << "bytes_written: " << bytes_written << std::endl;
        if (bytes_written < 0)
        {
            std::cout << "Serial Faild: could not write" << std::endl;
            return 0;
        }
        else
        {
            return 1;
        }
    }
    
    json receiveSerialData()
    {
        char buf[1024] = {0};
        memset(buf,0,sizeof(buf));
        int recv_data = read(fd_, buf, sizeof(buf));
        std::cout << "recv_data " << recv_data << std::endl;
        
        if (recv_data > 0)
        {
            std::string tmp_serial_data; // raw data
            std::string convert_serial_data; 

            // raw data 取り込み
            tmp_serial_data += std::string(buf, sizeof(buf));
            // std::cout << "Raw:" << tmp_serial_data << std::endl;

            // raw data をカット
            std::string input = tmp_serial_data;
            std::regex re("\\{[^{}]*\\}");
            std::smatch match;
    
            if (std::regex_search(input, match, re)) {
                convert_serial_data = match.str();
            }

            try
            {
                json command_data = json::parse(convert_serial_data);
                std::cout << "===================== parse success ! ======================" << std::endl;
                return command_data;
            }
            catch (const nlohmann::detail::parse_error& e)
            {

                std::cout << "parse_error です" << e.what() << std::endl;
                return command_data;

            }
            catch (const nlohmann::detail::type_error& e)
            {
                // terminate called after throwing an instance of 'nlohmann::detail::type_error'  what():  [json.exception.type_error.302] type must be number, but is null
                std::cout << "parse_error です" << e.what() << std::endl;
                return command_data;

            }
            catch (...)
            {
                std::cout << "未定義エラーです" << std::endl;
                return command_data;
            }
        }
        else
        {
            std::cout << "serial not catched" << std::endl;
            return command_data;
        }
    }
    
  private:
    int fd_;
};


class MsdStateSubscriver : public rclcpp::Node
{
    public:
        MsdStateSubscriver()
        : Node("msd_state_subscriver")
        {
            encoder_sub_ = this->create_subscription<msd_msgs::msg::Encoder>("msd/encoder", 
                                    130, std::bind(&MsdStateSubscriver::encoder_callback, this, _1));
            feedback_cylinder_sub_ = this->create_subscription<msd_msgs::msg::Cylinder>("msd/feedback_cylinder", 
                                    130, std::bind(&MsdStateSubscriver::cylinder_callback, this, _1));
            switch_sub_ = this->create_subscription<msd_msgs::msg::Switch>("msd/switch", 
                                    130, std::bind(&MsdStateSubscriver::switch_callback, this, _1));
            imu_sub_ = this->create_subscription<sensor_msgs::msg::Imu>("msd/fb_imu",
                                    130, std::bind(&MsdStateSubscriver::imu_callback, this, _1));
        }
    private:
        void encoder_callback(const msd_msgs::msg::Encoder::SharedPtr enc_msg)
        {
            feed_back_data["left_encoder"] = enc_msg->left_encoder;
            feed_back_data["right_encoder"] = enc_msg->right_encoder;
        }
        void cylinder_callback(const msd_msgs::msg::Cylinder::SharedPtr cyl_msg)
        {
            feed_back_data["cylinder_1"] = cyl_msg->cylinder1;
            feed_back_data["cylinder_2"] = cyl_msg->cylinder2;
        }
        void switch_callback(const msd_msgs::msg::Switch::SharedPtr relay_msg)
        {
            feed_back_data["power_relay"] = relay_msg->power_relay;
        }
        void imu_callback(const sensor_msgs::msg::Imu::SharedPtr imu_msg)
        {
            feed_back_data["imu_euler_x"] = imu_msg->angular_velocity.x;
            feed_back_data["imu_euler_y"] = imu_msg->angular_velocity.y;
        }
        rclcpp::Subscription<msd_msgs::msg::Encoder>::SharedPtr encoder_sub_;
        rclcpp::Subscription<msd_msgs::msg::Cylinder>::SharedPtr feedback_cylinder_sub_;
        rclcpp::Subscription<msd_msgs::msg::Switch>::SharedPtr switch_sub_;
        rclcpp::Subscription<sensor_msgs::msg::Imu>::SharedPtr imu_sub_;
};


class MsdCommandPublisher : public rclcpp::Node
{
  public:
    MsdCommandPublisher()
    : Node("msd_command_publisher")
    {
        serial_communication_ = std::make_shared<SerialCommunication>();
        cmd_vel_pub_ = this->create_publisher<geometry_msgs::msg::Twist>("msd/cmd_vel", 10);
        cmd_cyl_pub_ = this->create_publisher<msd_msgs::msg::Cylinder>("msd/cmd_cyl", 10);
        power_relay_pub_ = this->create_publisher<msd_msgs::msg::Switch>("msd/power_relay", 10);
        timer_ = this->create_wall_timer(
            130ms, 
            std::bind(&MsdCommandPublisher::timer_callback, 
            this
            ));
    }
  private:
    void timer_callback()
    {
        json ros_twist_command = serial_communication_->receiveSerialData();

        auto cmd_vel_msg = geometry_msgs::msg::Twist(); 
        auto cmd_cyl_msg = msd_msgs::msg::Cylinder();
        auto power_relay_msg = msd_msgs::msg::Switch();

        cmd_vel_msg.linear.x  = static_cast<double>(ros_twist_command["linear_x"]) * 0.462861317;
        cmd_vel_msg.angular.z = static_cast<double>(ros_twist_command["angular_z"]) * 0.785398163;
        cmd_cyl_msg.cylinder1 = ros_twist_command["cylinder_1"];
        cmd_cyl_msg.cylinder2 = ros_twist_command["cylinder_2"]; 
        power_relay_msg.power_relay = ros_twist_command["power_relay"];
        
        RCLCPP_INFO(this->get_logger(), "Pub: vel %.2f, %.2f [m/s], cyl %.2f, %.2f, relay: %i", 
                                        cmd_vel_msg.linear.x, cmd_vel_msg.angular.z, 
                                        cmd_cyl_msg.cylinder1, cmd_cyl_msg.cylinder2, 
                                        power_relay_msg.power_relay);

        cmd_vel_pub_->publish(cmd_vel_msg);
        cmd_cyl_pub_->publish(cmd_cyl_msg);
        power_relay_pub_->publish(power_relay_msg);

        std::string send_json = feed_back_data.dump() + "\n";
        serial_communication_->sendSerialCommand(send_json);
        std::cout << "send json contents: " << send_json << std::endl;
    }
    std::shared_ptr<SerialCommunication> serial_communication_;
    rclcpp::TimerBase::SharedPtr timer_;
    rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr cmd_vel_pub_;
    rclcpp::Publisher<msd_msgs::msg::Cylinder>::SharedPtr cmd_cyl_pub_;
    rclcpp::Publisher<msd_msgs::msg::Switch>::SharedPtr power_relay_pub_;
};


int main(int argc, char * argv[])
{
    rclcpp::init(argc, argv);
    rclcpp::executors::SingleThreadedExecutor exec;

    auto msd_state_subscriver = std::make_shared<MsdStateSubscriver>();
    auto msd_command_publisher = std::make_shared<MsdCommandPublisher>();

    exec.add_node(msd_state_subscriver);
    exec.add_node(msd_command_publisher);
    exec.spin();

    rclcpp::shutdown();
    return 0;
}