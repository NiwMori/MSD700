#include <iostream>
#include <chrono>
#include <memory>
#include <string>
#include <functional>
#include <unistd.h>
#include <fcntl.h>
#include <regex>
#include <termios.h>
#include <nlohmann/json.hpp>

#include "rclcpp/rclcpp.hpp"
#include "msd_msgs/msg/encoder.hpp"
#include "msd_msgs/msg/cylinder.hpp"
#include "msd_msgs/msg/switch.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "sensor_msgs/msg/imu.hpp"


using std::placeholders::_1;
using namespace std::chrono_literals;
using json = nlohmann::json;

class SerialCommunication;

json feedback_data = {
    {"left_encoder" , 0},
    {"right_encoder" , 0},
    {"fb_cylinder_1" , 0.00},
    {"fb_cylinder_2" ,0.00},
    {"power_relay_state" , 0},
    {"imu_euler_x" , 0},
    {"imu_euler_y" , 0},
    {"battery_level" , 0}
};
json command_data = {
    {"linear_x" , 0.00},
    {"angular_z" , 0.00},
    {"cylinder_1" , 0.00},
    {"cylinder_2" , 0.00},
    {"power_relay" , 1}
};


class SerialCommunication
{
  public:
    SerialCommunication(std::string serial_port)
    {
        openSerial(serial_port.c_str());
    }

    void openSerial(const char *device_name)
    {
        fd_ = open(device_name, O_RDWR | O_NOCTTY | O_NONBLOCK);
        std::cout << "fd_: " << fd_ << std::endl;

        fcntl(fd_, F_SETFL, 0);
        struct termios conf_tio;
        tcgetattr(fd_, &conf_tio);

        speed_t BAUDRATE = B115200;
        cfsetispeed(&conf_tio, BAUDRATE);
        cfsetospeed(&conf_tio, BAUDRATE);

        conf_tio.c_lflag &= ~(ECHO | ICANON);

        conf_tio.c_cc[VMIN] = 0;
        conf_tio.c_cc[VTIME] = 0;

        tcsetattr(fd_, TCSANOW, &conf_tio);
    }

    void sendSerialData(const std::string& message)
    {
        int bytes_written = write(fd_, message.c_str(), message.length());

        if (bytes_written < 0)
        {
            std::cout << "Serial Faild: could not write" << std::endl;
        }
        else
        {
            std::cout << "serial sended" << std::endl;
        }
    }

    std::string receiveSerialData(const std::string& init_object)
    {
        std::string recv_serial_data;
        char buf[1024] = {0};

        int recv_data = read(fd_, buf, sizeof(buf));
        
        if (recv_data > 0)
        {
            recv_serial_data += std::string(buf, recv_data);
            std::cout << "recv_serial_data: " << recv_serial_data << std::endl;
            return recv_serial_data;
        }
        else if (recv_data == 0)
        {
            // たぶん通信できてない．なにを返せばいいかわからん
            return init_object;
        }
        else
        {
            std::cout << "serial not catched" << std::endl;
            return init_object;
        }
    }

    json decodeSerialData(const std::string& serial_data, const std::string& init_data)
    {
        json json_document;
        std::string convert_serial_data;

        // raw data をカット
        std::string input = serial_data;
        std::regex re("\\{[^{}]*\\}");
        std::smatch match;
        if (std::regex_search(input, match, re)) {
            convert_serial_data = match.str();
        }
        std::cout << "convert_serial_data: " << convert_serial_data << std::endl;

        try
        {
            json json_document = json::parse(convert_serial_data);
            std::cout << "===================== parse success ! ======================" << std::endl;
            return json_document;
        }
        catch (const nlohmann::detail::parse_error& e)
        {
            std::cout << "===== parse_error です" << e.what() << std::endl;
            json json_document = json::parse(init_data);
            return json_document;

        }
        catch (const nlohmann::detail::type_error& e)
        {
            std::cout << "===== parse_error です" << e.what() << std::endl;
            json json_document = json::parse(init_data);
            return json_document;
        }
        catch (...)
        {
            std::cout << "===== 未定義エラーです" << std::endl;
            json json_document = json::parse(init_data);
            return json_document;
        }
    }
  private:
    int fd_;
};


class MsdCommandSubscriver : public rclcpp::Node
{
    public:
        MsdCommandSubscriver()
        : Node("msd_command_subscriver")
        {
            cmd_vel_sub_ = this->create_subscription<geometry_msgs::msg::Twist>("msd/cmd_vel",
                            130, std::bind(&MsdCommandSubscriver::cmd_vel_callback, this, _1));
            cmd_cyl_sub_ = this->create_subscription<msd_msgs::msg::Cylinder>("msd/cmd_cyl",
                            130, std::bind(&MsdCommandSubscriver::cmd_cyl_callback, this, _1));
            power_relay_sub_ = this->create_subscription<msd_msgs::msg::Switch>("msd/power_relay",
                            130, std::bind(&MsdCommandSubscriver::power_relay_callback, this, _1));
        }
    private:
        void cmd_vel_callback(const geometry_msgs::msg::Twist::SharedPtr cmd_vel)
        {
            RCLCPP_INFO(this->get_logger(), "Received cmd_vel: linear.x=%f, angular.z=%f", cmd_vel->linear.x, cmd_vel->angular.z);
            RCLCPP_INFO(this->get_logger(), "Received cmd_vel: linear.x=%f, angular.z=%f", cmd_vel->linear.x, cmd_vel->angular.z);
            command_data["linear_x"] = cmd_vel->linear.x;
            command_data["angular_z"] = cmd_vel->angular.z;
        }
        void cmd_cyl_callback(const msd_msgs::msg::Cylinder::SharedPtr cmd_cyl)
        {
            RCLCPP_INFO(this->get_logger(), "Received cmd_cyl: cylinder1=%f, cylinder2=%f", cmd_cyl->cylinder1, cmd_cyl->cylinder2);
            command_data["cylinder_1"] = cmd_cyl->cylinder1;
            command_data["cylinder_2"] = cmd_cyl->cylinder2;
        }
        void power_relay_callback(const msd_msgs::msg::Switch::SharedPtr power_relay)
        {
            RCLCPP_INFO(this->get_logger(), "Received power_relay: %d", power_relay->power_relay);
            command_data["power_relay"] = power_relay->power_relay;
        }
        rclcpp::Subscription<geometry_msgs::msg::Twist>::SharedPtr cmd_vel_sub_;
        rclcpp::Subscription<msd_msgs::msg::Cylinder>::SharedPtr cmd_cyl_sub_;
        rclcpp::Subscription<msd_msgs::msg::Switch>::SharedPtr power_relay_sub_;
};


class MsdStatePublisher : public rclcpp::Node
{
  public:
    MsdStatePublisher()
    : Node("msd_state_publisher")
    {
        serial_communication_ = std::make_shared<SerialCommunication>("/dev/msd-main-board");

        encoder_pub_           = this->create_publisher<msd_msgs::msg::Encoder>("msd/encoder", 10);
        feedback_cylinder_pub_ = this->create_publisher<msd_msgs::msg::Cylinder>("msd/feedback_cylinder", 10);
        switch_pub_            = this->create_publisher<msd_msgs::msg::Switch>("msd/switch", 10);
        imu_pub_               = this->create_publisher<sensor_msgs::msg::Imu>("msd/fb_imu", 10);

        timer_ = this->create_wall_timer(
            130ms,
            std::bind(&MsdStatePublisher::timer_callback,
            this
            ));
    }
  private:
    void timer_callback()
    {
        std::string init_data = feedback_data.dump() + "\n";
        std::string recv_serial = serial_communication_->receiveSerialData(init_data);
        // std::cout << "recv_serial: " << recv_serial << std::endl;
        json feedback_data = serial_communication_->decodeSerialData(recv_serial, init_data);
        std::cout << "feedback_data: " << feedback_data << std::endl;

        auto encoder_msg = msd_msgs::msg::Encoder();
        auto cylinder_msg = msd_msgs::msg::Cylinder();
        auto switch_msg = msd_msgs::msg::Switch();
        auto imu_msg = sensor_msgs::msg::Imu();

        encoder_msg.left_encoder    = feedback_data["left_encoder"];
        encoder_msg.right_encoder   = feedback_data["right_encoder"];
        cylinder_msg.cylinder1      = feedback_data["fb_cylinder_1"];
        cylinder_msg.cylinder2      = feedback_data["fb_cylinder_2"];
        imu_msg.angular_velocity.x  = feedback_data["imu_euler_x"];
        imu_msg.angular_velocity.y  = feedback_data["imu_euler_y"];

        RCLCPP_INFO(this->get_logger(), "Pub: encoder %i, %i [rpm], cyl %f, %f [-], relay %i imu: x:%f, y:%f",
                                        encoder_msg.left_encoder, encoder_msg.right_encoder,
                                        cylinder_msg.cylinder1, cylinder_msg.cylinder2,
                                        imu_msg.angular_velocity.x, imu_msg.angular_velocity.y);

        encoder_pub_->publish(encoder_msg);
        feedback_cylinder_pub_->publish(cylinder_msg);
        switch_pub_->publish(switch_msg);
        imu_pub_->publish(imu_msg);

        std::string send_serial = command_data.dump() + "\n";
        serial_communication_->sendSerialData(send_serial);
        std::cout << "sended:" << send_serial << std::endl;
    }
    std::shared_ptr<SerialCommunication> serial_communication_;
    rclcpp::TimerBase::SharedPtr timer_;
    rclcpp::Publisher<msd_msgs::msg::Encoder>::SharedPtr encoder_pub_;
    rclcpp::Publisher<msd_msgs::msg::Cylinder>::SharedPtr feedback_cylinder_pub_;
    rclcpp::Publisher<msd_msgs::msg::Switch>::SharedPtr switch_pub_;
    rclcpp::Publisher<sensor_msgs::msg::Imu>::SharedPtr imu_pub_;
};


int main(int argc, char * argv[])
{
    rclcpp::init(argc, argv);
    rclcpp::executors::SingleThreadedExecutor exec;

    auto msd_command_subscriver = std::make_shared<MsdCommandSubscriver>();
    auto msd_state_publisher = std::make_shared<MsdStatePublisher>();

    exec.add_node(msd_command_subscriver);
    exec.add_node(msd_state_publisher);
    exec.spin();

    rclcpp::shutdown();
    return 0;
}