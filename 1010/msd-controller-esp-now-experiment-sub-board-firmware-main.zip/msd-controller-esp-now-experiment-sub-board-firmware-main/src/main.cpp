#include <Adafruit_NeoPixel.h>
#include <Arduino.h>

#include <bitset>
#include <sstream>

#include "driver/gpio.h"
#include "driver/twai.h"

#include <WiFi.h>
#include <esp_now.h>

const gpio_num_t kCylinder1Forward = GPIO_NUM_15;
const gpio_num_t kCylinder1Reverse = GPIO_NUM_16;
const gpio_num_t kCylinder2Forward = GPIO_NUM_17;
const gpio_num_t kCylinder2Reverse = GPIO_NUM_18;
const gpio_num_t kCylinder1Feedback = GPIO_NUM_19;
const gpio_num_t kCylinder2Feedback = GPIO_NUM_2;

const gpio_num_t kPowerRelay = GPIO_NUM_1;
const gpio_num_t kEmergencyStopSwitch1 = GPIO_NUM_11;
const gpio_num_t kEmergencyStopSwitch2 = GPIO_NUM_12;

const gpio_num_t kPatliteRedLight = GPIO_NUM_8;
const gpio_num_t kPatliteGreenLight = GPIO_NUM_21;
const gpio_num_t kPatliteYellowLight = GPIO_NUM_47;
const gpio_num_t kPatliteRedFlash = GPIO_NUM_10;
const gpio_num_t kPatliteYellowFlash = GPIO_NUM_9;

const gpio_num_t kUart1Tx = GPIO_NUM_7; // UART1: Main
const gpio_num_t kUart1RX = GPIO_NUM_6;
const gpio_num_t kUart2Tx = GPIO_NUM_5; // UART2: Jetson
const gpio_num_t kUart2RX = GPIO_NUM_4;

const int kDebugRate = 115200;
const int kUart1Rate = 4800;
const int kUart2Rate = 4800;

float g_cylinder_1;
float g_cylinder_2;

void MoveCylinder(float input_value, gpio_num_t gpio_forward, gpio_num_t gpio_reverse);
void StopCylinder(gpio_num_t gpio_cylinder1_forward, gpio_num_t gpio_cylinder1_reverse, gpio_num_t gpio_cylinder2_forward, gpio_num_t gpio_cylinder2_reverse);

bool Patlite(String color, String mode, bool flag);

float cylinder_1 = 0;
float cylinder_2 = 0;
int power_relay = 0;
int msd_state = 4;

// ######## ESP-NOWの試験コードのエリア #########
int g_power_relay = 0; // 電源リレーの状態
// 受信データの構造体
unsigned long lastReceiveTime = 0; // 最後にデータを受信した時間
typedef struct struct_message
{
  char message[32];
} struct_message;

struct_message recvData;

void OnDataRecv(const uint8_t *macAddr, const uint8_t *incomingData, int len)
{
  // 突貫で書いたのでぐちゃぐちゃなのは勘弁してください

  memcpy(&recvData, incomingData, sizeof(recvData));
  // Serial.println(recvData.message);

  int parsedData[7];

  int emergencyStopSwitch = 0;
  int leftJoyStickX = 0;
  int leftJoyStickY = 0;
  int leftJoyStickZ = 0;
  int rightJoyStickX = 0;
  int rightJoyStickY = 0;
  int rightJoyStickZ = 0;

  String message = String(recvData.message);
  // Serial.println(message);

  int lastCommaIndex = 0; // 最後に見つかったカンマの文字列先頭からの位置
  bool invalidData = false;

  for (int i = 0; i < 7; i++)
  {
    lastCommaIndex = message.indexOf(',');
    // Serial.println(lastCommaIndex);
    if (i <= 5 && lastCommaIndex == -1)
    {
      invalidData = true;
      return; // カンマが見つからない場合は無効なデータ
    }
    parsedData[i] = message.substring(0, lastCommaIndex).toInt();
    message = message.substring(lastCommaIndex + 1);
    invalidData = false;
    lastReceiveTime = millis(); // データを受信した時間を更新
  }

  // Serial.print("ESP-NOW Data: ");
  // for (int i = 0; i < 7; i++) {
  //   Serial.print(parsedData[i]);
  //   Serial.print(",");
  // }
  // Serial.println();

  emergencyStopSwitch = parsedData[0];
  rightJoyStickX = parsedData[1];
  rightJoyStickY = parsedData[2];

  // とりあえずプロポ用の処理を流用
  float input_propo_joy_rightY = map(rightJoyStickY, 0, 1023, -100, 100) / 100.0;
  float input_propo_joy_rightX = map(rightJoyStickX, 0, 1023, -100, 100) / 100.0 * (-1.0);

  g_power_relay = 1 - emergencyStopSwitch; // プロポのスイッチは押すと電源が入る仕様なので、1から引いて反転
  cylinder_1 = input_propo_joy_rightY;
  cylinder_2 = input_propo_joy_rightX;
}

void checkEspNowTimeOut()
{
  if (millis() - lastReceiveTime > 100)
  { // 100msでタイムアウト
    // タイムアウト処理
    cylinder_1 = 0;
    cylinder_2 = 0;
  }
}

// ######## ESP-NOWの試験コードのエリアここまで #########

void setup()
{
  // GPIO mode init
  gpio_set_direction(kCylinder1Forward, GPIO_MODE_OUTPUT);
  gpio_set_direction(kCylinder1Reverse, GPIO_MODE_OUTPUT);
  gpio_set_direction(kCylinder2Forward, GPIO_MODE_OUTPUT);
  gpio_set_direction(kCylinder2Reverse, GPIO_MODE_OUTPUT);
  gpio_set_direction(kPowerRelay, GPIO_MODE_OUTPUT);
  gpio_set_direction(kEmergencyStopSwitch1, GPIO_MODE_INPUT);
  gpio_set_direction(kEmergencyStopSwitch2, GPIO_MODE_INPUT);
  gpio_set_direction(kPatliteRedLight, GPIO_MODE_OUTPUT);
  gpio_set_direction(kPatliteGreenLight, GPIO_MODE_OUTPUT);
  gpio_set_direction(kPatliteYellowLight, GPIO_MODE_OUTPUT);
  gpio_set_direction(kPatliteRedFlash, GPIO_MODE_OUTPUT);
  gpio_set_direction(kPatliteYellowFlash, GPIO_MODE_OUTPUT);

  gpio_set_direction(kCylinder1Feedback, GPIO_MODE_INPUT);
  gpio_set_direction(kCylinder2Feedback, GPIO_MODE_INPUT);

  // GPIO pullup or pulldown
  while (gpio_pulldown_en(kEmergencyStopSwitch1) != ESP_OK)
    ;
  while (gpio_pulldown_en(kEmergencyStopSwitch2) != ESP_OK)
    ;

  digitalWrite(kPatliteRedLight, LOW);
  digitalWrite(kPatliteRedFlash, LOW);
  digitalWrite(kPatliteYellowLight, LOW);
  digitalWrite(kPatliteYellowFlash, LOW);
  digitalWrite(kPatliteGreenLight, LOW);

  // Serial init
  Serial.begin(kDebugRate);
  while (!Serial)
    ;
  Serial1.begin(kUart1Rate, SERIAL_8E1, kUart1Tx, kUart1RX);
  while (!Serial1)
    ;

  // ######### ESP-NOWのテストコードのエリア #########
  // ESP-NOWの初期化
  WiFi.mode(WIFI_STA);
  if (esp_now_init() != ESP_OK)
  {
    Serial.println("Error initializing ESP-NOW");
    return;
  }
  // ESP-NOWの受信コールバック関数を登録
  esp_now_register_recv_cb(OnDataRecv);
  // ----------------------------------------------
  Patlite("Green", "Light", false); // Green light on
  Serial.println("===== Start Program =====");
}

void loop()
{
  MoveCylinder(cylinder_1, kCylinder1Forward, kCylinder1Reverse);
  MoveCylinder(cylinder_2, kCylinder2Forward, kCylinder2Reverse);
  checkEspNowTimeOut();
  if (g_power_relay == 0)
  {
    digitalWrite(kPowerRelay, LOW);
    Patlite("Yellow", "Light", false);
    Serial.println("Power Relay Off...");
  }
  else if (g_power_relay == 1)
  {
    digitalWrite(kPowerRelay, HIGH);
    Patlite("Yellow", "Light", true);
    Serial.println("Power Relay On...");
  }
}

void MoveCylinder(float input_value, gpio_num_t gpio_forward, gpio_num_t gpio_reverse)
{
  if (input_value >= 0.5)
  {
    digitalWrite(gpio_forward, HIGH);
    digitalWrite(gpio_reverse, LOW);
    // Serial.println("-----> Forward\n");
  }
  else if (input_value <= -0.5)
  {
    digitalWrite(gpio_forward, LOW);
    digitalWrite(gpio_reverse, HIGH);
    // Serial.println("-----> Reverse\n");
  }
  else
  {
    digitalWrite(gpio_forward, LOW);
    digitalWrite(gpio_reverse, LOW);
  }
}

void StopCylinder(gpio_num_t gpio_cylinder1_forward, gpio_num_t gpio_cylinder1_reverse, gpio_num_t gpio_cylinder2_forward, gpio_num_t gpio_cylinder2_reverse)
{
  digitalWrite(gpio_cylinder1_forward, LOW);
  digitalWrite(gpio_cylinder1_reverse, LOW);
  digitalWrite(gpio_cylinder2_forward, LOW);
  digitalWrite(gpio_cylinder2_reverse, LOW);
}

bool Patlite(String color, String mode, bool flag)
{
  if (color == "Red")
  {
    if (mode == "Flash")
    {
      if (flag)
      {
        digitalWrite(kPatliteRedLight, LOW);
        digitalWrite(kPatliteRedFlash, LOW);
        flag = false;
      }
      else
      {
        digitalWrite(kPatliteRedLight, HIGH);
        digitalWrite(kPatliteRedFlash, HIGH);
        flag = true;
        Serial.println("Red on...");
      }
    }
    else if (mode == "Light")
    {
      if (flag)
      {
        digitalWrite(kPatliteRedLight, LOW);
        flag = false;
      }
      else
      {
        digitalWrite(kPatliteRedLight, HIGH);
        flag = true;
        Serial.println("Red on...");
      }
    }
  }
  else if (color == "Green")
  {
    if (mode == "Flash")
    {
      Serial.println("Function is nothing...");
    }
    else if (mode == "Light")
    {
      if (flag)
      {
        digitalWrite(kPatliteGreenLight, LOW);
        flag = false;
      }
      else
      {
        digitalWrite(kPatliteGreenLight, HIGH);
        flag = true;
        Serial.println("Green on...");
      }
    }
  }
  else if (color == "Yellow")
  {
    if (mode == "Flash")
    {
      if (flag)
      {
        digitalWrite(kPatliteYellowLight, LOW);
        digitalWrite(kPatliteYellowFlash, LOW);
        flag = false;
      }
      else
      {
        digitalWrite(kPatliteYellowLight, HIGH);
        digitalWrite(kPatliteYellowFlash, HIGH);
        flag = true;
        Serial.println("Yellow on...");
      }
    }
    else if (mode == "Light")
    {
      if (flag)
      {
        digitalWrite(kPatliteYellowLight, LOW);
        flag = false;
      }
      else
      {
        digitalWrite(kPatliteYellowLight, HIGH);
        flag = true;
        Serial.println("Yellow on...");
      }
    }
  }

  return flag;
}